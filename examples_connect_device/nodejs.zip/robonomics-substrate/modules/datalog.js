"use strict";

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.promise.js");

require("core-js/modules/es.object.keys.js");

require("core-js/modules/es.symbol.js");

require("core-js/modules/es.array.filter.js");

require("core-js/modules/es.object.get-own-property-descriptor.js");

require("core-js/modules/es.array.for-each.js");

require("core-js/modules/web.dom-collections.for-each.js");

require("core-js/modules/es.object.get-own-property-descriptors.js");

require("core-js/modules/es.object.define-properties.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

require("core-js/modules/es.array.concat.js");

require("core-js/modules/es.array.map.js");

require("core-js/modules/es.object.define-property.js");

require("regenerator-runtime/runtime.js");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Datalog = /*#__PURE__*/function () {
  function Datalog(robonomics) {
    _classCallCheck(this, Datalog);

    this.robonomics = robonomics;
  }

  _createClass(Datalog, [{
    key: "write",
    value: function write(data) {
      return this.robonomics.api.tx.datalog.record(data);
    }
  }, {
    key: "maxId",
    value: function maxId() {
      var windowSize = this.robonomics.api.consts.datalog.windowSize;
      return windowSize.toNumber() - 1;
    }
  }, {
    key: "getLastId",
    value: function () {
      var _getLastId = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(address) {
        var id, full, index, max;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                id = null;
                full = false;
                _context.next = 4;
                return this.getIndex(address);

              case 4:
                index = _context.sent;

                if (index.start != index.end) {
                  id = index.end - 1;
                  max = this.maxId();

                  if (id < 0) {
                    id = max;
                  }

                  if (index.start > 0 || index.end === max) {
                    full = true;
                  }
                }

                return _context.abrupt("return", {
                  id: id,
                  full: full
                });

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getLastId(_x) {
        return _getLastId.apply(this, arguments);
      }

      return getLastId;
    }()
  }, {
    key: "getIndex",
    value: function () {
      var _getIndex = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(address) {
        var index;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.robonomics.api.query.datalog.datalogIndex(address);

              case 2:
                index = _context2.sent;
                return _context2.abrupt("return", {
                  start: index.start.toNumber(),
                  end: index.end.toNumber()
                });

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function getIndex(_x2) {
        return _getIndex.apply(this, arguments);
      }

      return getIndex;
    }()
  }, {
    key: "readByIndex",
    value: function () {
      var _readByIndex = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(address, index) {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.robonomics.api.query.datalog.datalogItem([address, index]);

              case 2:
                return _context3.abrupt("return", _context3.sent);

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function readByIndex(_x3, _x4) {
        return _readByIndex.apply(this, arguments);
      }

      return readByIndex;
    }()
  }, {
    key: "read",
    value: function () {
      var _read = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(address) {
        var start,
            end,
            log,
            id,
            index,
            data,
            _args4 = arguments;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                start = _args4.length > 1 && _args4[1] !== undefined ? _args4[1] : 0;
                end = _args4.length > 2 && _args4[2] !== undefined ? _args4[2] : null;
                log = [];

                if (end) {
                  _context4.next = 18;
                  break;
                }

                _context4.next = 6;
                return this.getLastId(address);

              case 6:
                id = _context4.sent;

                if (!id.full) {
                  _context4.next = 17;
                  break;
                }

                _context4.next = 10;
                return this.read(address, id.id + 1, this.maxId());

              case 10:
                _context4.t0 = _context4.sent;
                _context4.next = 13;
                return this.read(address, 0, id.id);

              case 13:
                _context4.t1 = _context4.sent;
                return _context4.abrupt("return", _context4.t0.concat.call(_context4.t0, _context4.t1));

              case 17:
                end = id.id;

              case 18:
                if (!(end !== null)) {
                  _context4.next = 28;
                  break;
                }

                index = start;

              case 20:
                if (!(index <= end)) {
                  _context4.next = 28;
                  break;
                }

                _context4.next = 23;
                return this.readByIndex(address, index);

              case 23:
                data = _context4.sent;
                log.push(data);

              case 25:
                index++;
                _context4.next = 20;
                break;

              case 28:
                return _context4.abrupt("return", log);

              case 29:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function read(_x5) {
        return _read.apply(this, arguments);
      }

      return read;
    }()
  }, {
    key: "on",
    value: function () {
      var _on = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var filter,
            cb,
            _args5 = arguments;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                filter = _args5.length > 0 && _args5[0] !== undefined ? _args5[0] : {};
                cb = _args5.length > 1 ? _args5[1] : undefined;
                return _context5.abrupt("return", this.robonomics.on(_objectSpread(_objectSpread({}, filter), {}, {
                  section: "datalog",
                  method: "NewRecord"
                }), function (result) {
                  cb(result.map(function (item) {
                    return {
                      account: item.account,
                      success: item.success,
                      moment: item.data[0],
                      data: item.data[1]
                    };
                  }));
                }));

              case 3:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function on() {
        return _on.apply(this, arguments);
      }

      return on;
    }()
  }]);

  return Datalog;
}();

exports["default"] = Datalog;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9yb2Jvbm9taWNzLXN1YnN0cmF0ZS9tb2R1bGVzL2RhdGFsb2cuanMiXSwibmFtZXMiOlsiRGF0YWxvZyIsInJvYm9ub21pY3MiLCJkYXRhIiwiYXBpIiwidHgiLCJkYXRhbG9nIiwicmVjb3JkIiwid2luZG93U2l6ZSIsImNvbnN0cyIsInRvTnVtYmVyIiwiYWRkcmVzcyIsImlkIiwiZnVsbCIsImdldEluZGV4IiwiaW5kZXgiLCJzdGFydCIsImVuZCIsIm1heCIsIm1heElkIiwicXVlcnkiLCJkYXRhbG9nSW5kZXgiLCJkYXRhbG9nSXRlbSIsImxvZyIsImdldExhc3RJZCIsInJlYWQiLCJjb25jYXQiLCJyZWFkQnlJbmRleCIsInB1c2giLCJmaWx0ZXIiLCJjYiIsIm9uIiwic2VjdGlvbiIsIm1ldGhvZCIsInJlc3VsdCIsIm1hcCIsIml0ZW0iLCJhY2NvdW50Iiwic3VjY2VzcyIsIm1vbWVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBQXFCQSxPO0FBQ25CLG1CQUFZQyxVQUFaLEVBQXdCO0FBQUE7O0FBQ3RCLFNBQUtBLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0Q7Ozs7V0FDRCxlQUFNQyxJQUFOLEVBQVk7QUFDVixhQUFPLEtBQUtELFVBQUwsQ0FBZ0JFLEdBQWhCLENBQW9CQyxFQUFwQixDQUF1QkMsT0FBdkIsQ0FBK0JDLE1BQS9CLENBQXNDSixJQUF0QyxDQUFQO0FBQ0Q7OztXQUNELGlCQUFRO0FBQ04sVUFBTUssVUFBVSxHQUFHLEtBQUtOLFVBQUwsQ0FBZ0JFLEdBQWhCLENBQW9CSyxNQUFwQixDQUEyQkgsT0FBM0IsQ0FBbUNFLFVBQXREO0FBQ0EsYUFBT0EsVUFBVSxDQUFDRSxRQUFYLEtBQXdCLENBQS9CO0FBQ0Q7Ozs7K0VBQ0QsaUJBQWdCQyxPQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDTUMsZ0JBQUFBLEVBRE4sR0FDVyxJQURYO0FBRU1DLGdCQUFBQSxJQUZOLEdBRWEsS0FGYjtBQUFBO0FBQUEsdUJBR3NCLEtBQUtDLFFBQUwsQ0FBY0gsT0FBZCxDQUh0Qjs7QUFBQTtBQUdRSSxnQkFBQUEsS0FIUjs7QUFJRSxvQkFBSUEsS0FBSyxDQUFDQyxLQUFOLElBQWVELEtBQUssQ0FBQ0UsR0FBekIsRUFBOEI7QUFDNUJMLGtCQUFBQSxFQUFFLEdBQUdHLEtBQUssQ0FBQ0UsR0FBTixHQUFZLENBQWpCO0FBQ01DLGtCQUFBQSxHQUZzQixHQUVoQixLQUFLQyxLQUFMLEVBRmdCOztBQUc1QixzQkFBSVAsRUFBRSxHQUFHLENBQVQsRUFBWTtBQUNWQSxvQkFBQUEsRUFBRSxHQUFHTSxHQUFMO0FBQ0Q7O0FBQ0Qsc0JBQUlILEtBQUssQ0FBQ0MsS0FBTixHQUFjLENBQWQsSUFBbUJELEtBQUssQ0FBQ0UsR0FBTixLQUFjQyxHQUFyQyxFQUEwQztBQUN4Q0wsb0JBQUFBLElBQUksR0FBRyxJQUFQO0FBQ0Q7QUFDRjs7QUFiSCxpREFjUztBQUFFRCxrQkFBQUEsRUFBRSxFQUFGQSxFQUFGO0FBQU1DLGtCQUFBQSxJQUFJLEVBQUpBO0FBQU4saUJBZFQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTzs7Ozs7Ozs7Ozs7OEVBZ0JBLGtCQUFlRixPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ3NCLEtBQUtULFVBQUwsQ0FBZ0JFLEdBQWhCLENBQW9CZ0IsS0FBcEIsQ0FBMEJkLE9BQTFCLENBQWtDZSxZQUFsQyxDQUErQ1YsT0FBL0MsQ0FEdEI7O0FBQUE7QUFDUUksZ0JBQUFBLEtBRFI7QUFBQSxrREFFUztBQUNMQyxrQkFBQUEsS0FBSyxFQUFFRCxLQUFLLENBQUNDLEtBQU4sQ0FBWU4sUUFBWixFQURGO0FBRUxPLGtCQUFBQSxHQUFHLEVBQUVGLEtBQUssQ0FBQ0UsR0FBTixDQUFVUCxRQUFWO0FBRkEsaUJBRlQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTzs7Ozs7Ozs7Ozs7aUZBT0Esa0JBQWtCQyxPQUFsQixFQUEyQkksS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ2UsS0FBS2IsVUFBTCxDQUFnQkUsR0FBaEIsQ0FBb0JnQixLQUFwQixDQUEwQmQsT0FBMUIsQ0FBa0NnQixXQUFsQyxDQUE4QyxDQUN6RFgsT0FEeUQsRUFFekRJLEtBRnlELENBQTlDLENBRGY7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPOzs7Ozs7Ozs7OzswRUFNQSxrQkFBV0osT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBb0JLLGdCQUFBQSxLQUFwQiw4REFBNEIsQ0FBNUI7QUFBK0JDLGdCQUFBQSxHQUEvQiw4REFBcUMsSUFBckM7QUFDUU0sZ0JBQUFBLEdBRFIsR0FDYyxFQURkOztBQUFBLG9CQUVPTixHQUZQO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUJBR3FCLEtBQUtPLFNBQUwsQ0FBZWIsT0FBZixDQUhyQjs7QUFBQTtBQUdVQyxnQkFBQUEsRUFIVjs7QUFBQSxxQkFJUUEsRUFBRSxDQUFDQyxJQUpYO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUJBS29CLEtBQUtZLElBQUwsQ0FBVWQsT0FBVixFQUFtQkMsRUFBRSxDQUFDQSxFQUFILEdBQVEsQ0FBM0IsRUFBOEIsS0FBS08sS0FBTCxFQUE5QixDQUxwQjs7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNYyxLQUFLTSxJQUFMLENBQVVkLE9BQVYsRUFBbUIsQ0FBbkIsRUFBc0JDLEVBQUUsQ0FBQ0EsRUFBekIsQ0FOZDs7QUFBQTtBQUFBO0FBQUEsK0RBS2lFYyxNQUxqRTs7QUFBQTtBQVNNVCxnQkFBQUEsR0FBRyxHQUFHTCxFQUFFLENBQUNBLEVBQVQ7O0FBVE47QUFBQSxzQkFZTUssR0FBRyxLQUFLLElBWmQ7QUFBQTtBQUFBO0FBQUE7O0FBYWFGLGdCQUFBQSxLQWJiLEdBYXFCQyxLQWJyQjs7QUFBQTtBQUFBLHNCQWE0QkQsS0FBSyxJQUFJRSxHQWJyQztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHVCQWN5QixLQUFLVSxXQUFMLENBQWlCaEIsT0FBakIsRUFBMEJJLEtBQTFCLENBZHpCOztBQUFBO0FBY1laLGdCQUFBQSxJQWRaO0FBZU1vQixnQkFBQUEsR0FBRyxDQUFDSyxJQUFKLENBQVN6QixJQUFUOztBQWZOO0FBYTBDWSxnQkFBQUEsS0FBSyxFQWIvQztBQUFBO0FBQUE7O0FBQUE7QUFBQSxrREFrQlNRLEdBbEJUOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE87Ozs7Ozs7Ozs7O3dFQW9CQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQVNNLGdCQUFBQSxNQUFULDhEQUFrQixFQUFsQjtBQUFzQkMsZ0JBQUFBLEVBQXRCO0FBQUEsa0RBQ1MsS0FBSzVCLFVBQUwsQ0FBZ0I2QixFQUFoQixpQ0FDQUYsTUFEQTtBQUNRRyxrQkFBQUEsT0FBTyxFQUFFLFNBRGpCO0FBQzRCQyxrQkFBQUEsTUFBTSxFQUFFO0FBRHBDLG9CQUVMLFVBQUNDLE1BQUQsRUFBWTtBQUNWSixrQkFBQUEsRUFBRSxDQUNBSSxNQUFNLENBQUNDLEdBQVAsQ0FBVyxVQUFDQyxJQUFELEVBQVU7QUFDbkIsMkJBQU87QUFDTEMsc0JBQUFBLE9BQU8sRUFBRUQsSUFBSSxDQUFDQyxPQURUO0FBRUxDLHNCQUFBQSxPQUFPLEVBQUVGLElBQUksQ0FBQ0UsT0FGVDtBQUdMQyxzQkFBQUEsTUFBTSxFQUFFSCxJQUFJLENBQUNqQyxJQUFMLENBQVUsQ0FBVixDQUhIO0FBSUxBLHNCQUFBQSxJQUFJLEVBQUVpQyxJQUFJLENBQUNqQyxJQUFMLENBQVUsQ0FBVjtBQUpELHFCQUFQO0FBTUQsbUJBUEQsQ0FEQSxDQUFGO0FBVUQsaUJBYkksQ0FEVDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGF0YWxvZyB7XG4gIGNvbnN0cnVjdG9yKHJvYm9ub21pY3MpIHtcbiAgICB0aGlzLnJvYm9ub21pY3MgPSByb2Jvbm9taWNzO1xuICB9XG4gIHdyaXRlKGRhdGEpIHtcbiAgICByZXR1cm4gdGhpcy5yb2Jvbm9taWNzLmFwaS50eC5kYXRhbG9nLnJlY29yZChkYXRhKTtcbiAgfVxuICBtYXhJZCgpIHtcbiAgICBjb25zdCB3aW5kb3dTaXplID0gdGhpcy5yb2Jvbm9taWNzLmFwaS5jb25zdHMuZGF0YWxvZy53aW5kb3dTaXplO1xuICAgIHJldHVybiB3aW5kb3dTaXplLnRvTnVtYmVyKCkgLSAxO1xuICB9XG4gIGFzeW5jIGdldExhc3RJZChhZGRyZXNzKSB7XG4gICAgbGV0IGlkID0gbnVsbDtcbiAgICBsZXQgZnVsbCA9IGZhbHNlO1xuICAgIGNvbnN0IGluZGV4ID0gYXdhaXQgdGhpcy5nZXRJbmRleChhZGRyZXNzKTtcbiAgICBpZiAoaW5kZXguc3RhcnQgIT0gaW5kZXguZW5kKSB7XG4gICAgICBpZCA9IGluZGV4LmVuZCAtIDE7XG4gICAgICBjb25zdCBtYXggPSB0aGlzLm1heElkKCk7XG4gICAgICBpZiAoaWQgPCAwKSB7XG4gICAgICAgIGlkID0gbWF4O1xuICAgICAgfVxuICAgICAgaWYgKGluZGV4LnN0YXJ0ID4gMCB8fCBpbmRleC5lbmQgPT09IG1heCkge1xuICAgICAgICBmdWxsID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHsgaWQsIGZ1bGwgfTtcbiAgfVxuICBhc3luYyBnZXRJbmRleChhZGRyZXNzKSB7XG4gICAgY29uc3QgaW5kZXggPSBhd2FpdCB0aGlzLnJvYm9ub21pY3MuYXBpLnF1ZXJ5LmRhdGFsb2cuZGF0YWxvZ0luZGV4KGFkZHJlc3MpO1xuICAgIHJldHVybiB7XG4gICAgICBzdGFydDogaW5kZXguc3RhcnQudG9OdW1iZXIoKSxcbiAgICAgIGVuZDogaW5kZXguZW5kLnRvTnVtYmVyKClcbiAgICB9O1xuICB9XG4gIGFzeW5jIHJlYWRCeUluZGV4KGFkZHJlc3MsIGluZGV4KSB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMucm9ib25vbWljcy5hcGkucXVlcnkuZGF0YWxvZy5kYXRhbG9nSXRlbShbXG4gICAgICBhZGRyZXNzLFxuICAgICAgaW5kZXhcbiAgICBdKTtcbiAgfVxuICBhc3luYyByZWFkKGFkZHJlc3MsIHN0YXJ0ID0gMCwgZW5kID0gbnVsbCkge1xuICAgIGNvbnN0IGxvZyA9IFtdO1xuICAgIGlmICghZW5kKSB7XG4gICAgICBjb25zdCBpZCA9IGF3YWl0IHRoaXMuZ2V0TGFzdElkKGFkZHJlc3MpO1xuICAgICAgaWYgKGlkLmZ1bGwpIHtcbiAgICAgICAgcmV0dXJuIChhd2FpdCB0aGlzLnJlYWQoYWRkcmVzcywgaWQuaWQgKyAxLCB0aGlzLm1heElkKCkpKS5jb25jYXQoXG4gICAgICAgICAgYXdhaXQgdGhpcy5yZWFkKGFkZHJlc3MsIDAsIGlkLmlkKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZW5kID0gaWQuaWQ7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChlbmQgIT09IG51bGwpIHtcbiAgICAgIGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDw9IGVuZDsgaW5kZXgrKykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5yZWFkQnlJbmRleChhZGRyZXNzLCBpbmRleCk7XG4gICAgICAgIGxvZy5wdXNoKGRhdGEpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbG9nO1xuICB9XG4gIGFzeW5jIG9uKGZpbHRlciA9IHt9LCBjYikge1xuICAgIHJldHVybiB0aGlzLnJvYm9ub21pY3Mub24oXG4gICAgICB7IC4uLmZpbHRlciwgc2VjdGlvbjogXCJkYXRhbG9nXCIsIG1ldGhvZDogXCJOZXdSZWNvcmRcIiB9LFxuICAgICAgKHJlc3VsdCkgPT4ge1xuICAgICAgICBjYihcbiAgICAgICAgICByZXN1bHQubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBhY2NvdW50OiBpdGVtLmFjY291bnQsXG4gICAgICAgICAgICAgIHN1Y2Nlc3M6IGl0ZW0uc3VjY2VzcyxcbiAgICAgICAgICAgICAgbW9tZW50OiBpdGVtLmRhdGFbMF0sXG4gICAgICAgICAgICAgIGRhdGE6IGl0ZW0uZGF0YVsxXVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfVxuICAgICk7XG4gIH1cbn1cbiJdfQ==