"use strict";

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.promise.js");

require("core-js/modules/es.object.keys.js");

require("core-js/modules/es.symbol.js");

require("core-js/modules/es.array.filter.js");

require("core-js/modules/es.object.get-own-property-descriptor.js");

require("core-js/modules/es.array.for-each.js");

require("core-js/modules/web.dom-collections.for-each.js");

require("core-js/modules/es.object.get-own-property-descriptors.js");

require("core-js/modules/es.object.define-properties.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

require("regenerator-runtime/runtime.js");

require("core-js/modules/es.array.map.js");

require("core-js/modules/es.object.define-property.js");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Launch = /*#__PURE__*/function () {
  function Launch(robonomics) {
    _classCallCheck(this, Launch);

    this.robonomics = robonomics;
  }

  _createClass(Launch, [{
    key: "send",
    value: function send(address, param) {
      return this.robonomics.api.tx.launch.launch(address, param);
    }
  }, {
    key: "on",
    value: function () {
      var _on = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var filter,
            cb,
            _args = arguments;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                filter = _args.length > 0 && _args[0] !== undefined ? _args[0] : {};
                cb = _args.length > 1 ? _args[1] : undefined;
                return _context.abrupt("return", this.robonomics.on(_objectSpread(_objectSpread({}, filter), {}, {
                  section: "launch",
                  method: "NewLaunch"
                }), function (result) {
                  cb(result.map(function (item) {
                    return {
                      account: item.account,
                      success: item.success,
                      robot: item.data[0].toHuman(),
                      parameter: item.data[1].toHuman()
                    };
                  }));
                }));

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function on() {
        return _on.apply(this, arguments);
      }

      return on;
    }()
  }]);

  return Launch;
}();

exports["default"] = Launch;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9yb2Jvbm9taWNzLXN1YnN0cmF0ZS9tb2R1bGVzL2xhdW5jaC5qcyJdLCJuYW1lcyI6WyJMYXVuY2giLCJyb2Jvbm9taWNzIiwiYWRkcmVzcyIsInBhcmFtIiwiYXBpIiwidHgiLCJsYXVuY2giLCJmaWx0ZXIiLCJjYiIsIm9uIiwic2VjdGlvbiIsIm1ldGhvZCIsInJlc3VsdCIsIm1hcCIsIml0ZW0iLCJhY2NvdW50Iiwic3VjY2VzcyIsInJvYm90IiwiZGF0YSIsInRvSHVtYW4iLCJwYXJhbWV0ZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFBcUJBLE07QUFDbkIsa0JBQVlDLFVBQVosRUFBd0I7QUFBQTs7QUFDdEIsU0FBS0EsVUFBTCxHQUFrQkEsVUFBbEI7QUFDRDs7OztXQUNELGNBQUtDLE9BQUwsRUFBY0MsS0FBZCxFQUFxQjtBQUNuQixhQUFPLEtBQUtGLFVBQUwsQ0FBZ0JHLEdBQWhCLENBQW9CQyxFQUFwQixDQUF1QkMsTUFBdkIsQ0FBOEJBLE1BQTlCLENBQXFDSixPQUFyQyxFQUE4Q0MsS0FBOUMsQ0FBUDtBQUNEOzs7O3dFQUNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBU0ksZ0JBQUFBLE1BQVQsMkRBQWtCLEVBQWxCO0FBQXNCQyxnQkFBQUEsRUFBdEI7QUFBQSxpREFDUyxLQUFLUCxVQUFMLENBQWdCUSxFQUFoQixpQ0FDQUYsTUFEQTtBQUNRRyxrQkFBQUEsT0FBTyxFQUFFLFFBRGpCO0FBQzJCQyxrQkFBQUEsTUFBTSxFQUFFO0FBRG5DLG9CQUVMLFVBQUNDLE1BQUQsRUFBWTtBQUNWSixrQkFBQUEsRUFBRSxDQUNBSSxNQUFNLENBQUNDLEdBQVAsQ0FBVyxVQUFDQyxJQUFELEVBQVU7QUFDbkIsMkJBQU87QUFDTEMsc0JBQUFBLE9BQU8sRUFBRUQsSUFBSSxDQUFDQyxPQURUO0FBRUxDLHNCQUFBQSxPQUFPLEVBQUVGLElBQUksQ0FBQ0UsT0FGVDtBQUdMQyxzQkFBQUEsS0FBSyxFQUFFSCxJQUFJLENBQUNJLElBQUwsQ0FBVSxDQUFWLEVBQWFDLE9BQWIsRUFIRjtBQUlMQyxzQkFBQUEsU0FBUyxFQUFFTixJQUFJLENBQUNJLElBQUwsQ0FBVSxDQUFWLEVBQWFDLE9BQWI7QUFKTixxQkFBUDtBQU1ELG1CQVBELENBREEsQ0FBRjtBQVVELGlCQWJJLENBRFQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGNsYXNzIExhdW5jaCB7XG4gIGNvbnN0cnVjdG9yKHJvYm9ub21pY3MpIHtcbiAgICB0aGlzLnJvYm9ub21pY3MgPSByb2Jvbm9taWNzO1xuICB9XG4gIHNlbmQoYWRkcmVzcywgcGFyYW0pIHtcbiAgICByZXR1cm4gdGhpcy5yb2Jvbm9taWNzLmFwaS50eC5sYXVuY2gubGF1bmNoKGFkZHJlc3MsIHBhcmFtKTtcbiAgfVxuICBhc3luYyBvbihmaWx0ZXIgPSB7fSwgY2IpIHtcbiAgICByZXR1cm4gdGhpcy5yb2Jvbm9taWNzLm9uKFxuICAgICAgeyAuLi5maWx0ZXIsIHNlY3Rpb246IFwibGF1bmNoXCIsIG1ldGhvZDogXCJOZXdMYXVuY2hcIiB9LFxuICAgICAgKHJlc3VsdCkgPT4ge1xuICAgICAgICBjYihcbiAgICAgICAgICByZXN1bHQubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBhY2NvdW50OiBpdGVtLmFjY291bnQsXG4gICAgICAgICAgICAgIHN1Y2Nlc3M6IGl0ZW0uc3VjY2VzcyxcbiAgICAgICAgICAgICAgcm9ib3Q6IGl0ZW0uZGF0YVswXS50b0h1bWFuKCksXG4gICAgICAgICAgICAgIHBhcmFtZXRlcjogaXRlbS5kYXRhWzFdLnRvSHVtYW4oKVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfVxuICAgICk7XG4gIH1cbn1cbiJdfQ==