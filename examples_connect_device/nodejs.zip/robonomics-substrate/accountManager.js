"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

require("core-js/modules/es.reflect.construct.js");

require("core-js/modules/es.function.bind.js");

require("core-js/modules/es.array.iterator.js");

require("core-js/modules/es.map.js");

require("core-js/modules/es.string.iterator.js");

require("core-js/modules/web.dom-collections.iterator.js");

require("core-js/modules/es.object.create.js");

require("core-js/modules/es.object.define-property.js");

require("core-js/modules/es.array.slice.js");

require("core-js/modules/es.array.from.js");

require("core-js/modules/es.symbol.js");

require("core-js/modules/es.symbol.description.js");

require("core-js/modules/es.symbol.iterator.js");

require("core-js/modules/es.array.is-array.js");

require("core-js/modules/es.object.keys.js");

require("core-js/modules/es.array.filter.js");

require("core-js/modules/es.object.get-own-property-descriptor.js");

require("core-js/modules/es.object.get-own-property-descriptors.js");

require("core-js/modules/es.object.define-properties.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

require("regenerator-runtime/runtime.js");

require("core-js/modules/es.array.concat.js");

require("core-js/modules/es.object.set-prototype-of.js");

require("core-js/modules/es.object.get-prototype-of.js");

require("core-js/modules/web.timers.js");

require("core-js/modules/es.array.map.js");

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.promise.js");

require("core-js/modules/es.array.index-of.js");

require("core-js/modules/es.array.splice.js");

require("core-js/modules/es.array.for-each.js");

require("core-js/modules/web.dom-collections.for-each.js");

require("core-js/modules/es.function.name.js");

require("core-js/modules/es.array.join.js");

require("core-js/modules/es.date.to-string.js");

require("core-js/modules/es.regexp.to-string.js");

var _api = require("@polkadot/api");

var _utilCrypto = require("@polkadot/util-crypto");

var _util = require("@polkadot/util");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _wrapNativeSuper(Class) { var _cache = typeof Map === "function" ? new Map() : undefined; _wrapNativeSuper = function _wrapNativeSuper(Class) { if (Class === null || !_isNativeFunction(Class)) return Class; if (typeof Class !== "function") { throw new TypeError("Super expression must either be null or a function"); } if (typeof _cache !== "undefined") { if (_cache.has(Class)) return _cache.get(Class); _cache.set(Class, Wrapper); } function Wrapper() { return _construct(Class, arguments, _getPrototypeOf(this).constructor); } Wrapper.prototype = Object.create(Class.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } }); return _setPrototypeOf(Wrapper, Class); }; return _wrapNativeSuper(Class); }

function _construct(Parent, args, Class) { if (_isNativeReflectConstruct()) { _construct = Reflect.construct; } else { _construct = function _construct(Parent, args, Class) { var a = [null]; a.push.apply(a, args); var Constructor = Function.bind.apply(Parent, a); var instance = new Constructor(); if (Class) _setPrototypeOf(instance, Class.prototype); return instance; }; } return _construct.apply(null, arguments); }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _isNativeFunction(fn) { return Function.toString.call(fn).indexOf("[native code]") !== -1; }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var keyring = new _api.Keyring();

var ErrorAccount = /*#__PURE__*/function (_Error) {
  _inherits(ErrorAccount, _Error);

  var _super = _createSuper(ErrorAccount);

  function ErrorAccount() {
    var _this;

    var status = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

    _classCallCheck(this, ErrorAccount);

    for (var _len = arguments.length, params = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      params[_key - 1] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(params));
    _this.status = status;
    return _this;
  }

  return ErrorAccount;
}( /*#__PURE__*/_wrapNativeSuper(Error));

var _isReady = false;

var AccountManager = /*#__PURE__*/function () {
  function AccountManager() {
    var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck(this, AccountManager);

    this.api = null;
    this.config = config;
    this.account = null;
    this.listeners = [];
    _isReady = true;
  }

  _createClass(AccountManager, [{
    key: "setAccounts",
    value: function setAccounts() {
      var keys = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

      var _iterator = _createForOfIteratorHelper(keys),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var item = _step.value;
          var suri = void 0;
          var meta = {};
          var type = this.config.type || "sr25519";

          if (item.suri) {
            suri = item.suri;

            if (item.meta) {
              meta = item.meta;
            }

            if (item.type) {
              type = item.type;
            }
          } else {
            suri = item;
          }

          keyring.addFromUri(suri, meta, type);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      if (keys.length) {
        this.selectAccountByAddress(this.getAccounts()[0].address);
      }
    }
  }, {
    key: "setApi",
    value: function setApi(api) {
      this.api = api;
    }
  }, {
    key: "onReady",
    value: function onReady(cb) {
      var _this2 = this;

      if (_isReady) {
        cb();
      } else {
        setTimeout(function () {
          _this2.onReady(cb);
        }, 1000);
      }
    }
  }, {
    key: "getAccounts",
    value: function getAccounts() {
      var _this3 = this;

      var pairs = keyring.getPairs();
      return pairs.map(function (pair) {
        return _objectSpread(_objectSpread({}, pair), {}, {
          address: (0, _utilCrypto.encodeAddress)(pair.address, _this3.config.ss58Format || _this3.api.registry.chainSS58)
        });
      });
    }
  }, {
    key: "selectAccountByAddress",
    value: function () {
      var _selectAccountByAddress = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(address) {
        var account, _iterator2, _step2, cb;

        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                account = keyring.getPair(address);
                this.account = _objectSpread(_objectSpread({}, account), {}, {
                  address: (0, _utilCrypto.encodeAddress)(account.address, this.config.ss58Format || this.api.registry.chainSS58)
                });

                this.account.signMsg = /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(data) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            return _context.abrupt("return", Promise.resolve((0, _util.u8aToHex)(account.sign(data))));

                          case 1:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee);
                  }));

                  return function (_x2) {
                    return _ref.apply(this, arguments);
                  };
                }();

                _iterator2 = _createForOfIteratorHelper(this.listeners);

                try {
                  for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                    cb = _step2.value;
                    cb(this.account);
                  }
                } catch (err) {
                  _iterator2.e(err);
                } finally {
                  _iterator2.f();
                }

                return _context2.abrupt("return", this.account);

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function selectAccountByAddress(_x) {
        return _selectAccountByAddress.apply(this, arguments);
      }

      return selectAccountByAddress;
    }()
  }, {
    key: "onChange",
    value: function onChange(cb) {
      var _this4 = this;

      this.listeners.push(cb);
      return function () {
        var i = _this4.listeners.indexOf(cb);

        _this4.listeners.splice(i, 1);
      };
    }
  }, {
    key: "signAndSend",
    value: function () {
      var _signAndSend = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(tx) {
        var _this5 = this;

        var options,
            _args4 = arguments;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                options = _args4.length > 1 && _args4[1] !== undefined ? _args4[1] : {};

                if (!(this.account === null)) {
                  _context4.next = 3;
                  break;
                }

                throw new ErrorAccount(3, "No account selected");

              case 3:
                return _context4.abrupt("return", new Promise(function (resolve, reject) {
                  tx.signAndSend(_this5.account.meta.isInjected ? _this5.account.address : _this5.account, options, function (result) {
                    if (result.status.isInBlock) {
                      result.events.forEach( /*#__PURE__*/function () {
                        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(events) {
                          var _events$event, data, method, section, phase, message, mod, _mod$registry$findMet, docs, name, _section, block;

                          return regeneratorRuntime.wrap(function _callee3$(_context3) {
                            while (1) {
                              switch (_context3.prev = _context3.next) {
                                case 0:
                                  _events$event = events.event, data = _events$event.data, method = _events$event.method, section = _events$event.section, phase = events.phase;

                                  if (!(section === "system" && method === "ExtrinsicFailed")) {
                                    _context3.next = 7;
                                    break;
                                  }

                                  message = "Error";

                                  if (data[0].isModule) {
                                    mod = data[0].asModule; // const mod = result.dispatchError.asModule;

                                    // const mod = result.dispatchError.asModule;
                                    _mod$registry$findMet = mod.registry.findMetaError(mod), docs = _mod$registry$findMet.docs, name = _mod$registry$findMet.name, _section = _mod$registry$findMet.section;
                                    console.log(name, _section, docs);
                                    message = docs.join(", ");
                                  }

                                  return _context3.abrupt("return", reject(new ErrorAccount(4, message)));

                                case 7:
                                  if (!(section === "system" && method === "ExtrinsicSuccess")) {
                                    _context3.next = 12;
                                    break;
                                  }

                                  _context3.next = 10;
                                  return _this5.api.rpc.chain.getBlock(result.status.asInBlock.toString());

                                case 10:
                                  block = _context3.sent;
                                  resolve({
                                    block: result.status.asInBlock.toString(),
                                    blockNumber: block.block.header.number.toNumber(),
                                    // const index = phase.value.toNumber();
                                    txIndex: phase.asApplyExtrinsic.toHuman(),
                                    tx: tx.hash.toString()
                                  });

                                case 12:
                                case "end":
                                  return _context3.stop();
                              }
                            }
                          }, _callee3);
                        }));

                        return function (_x4) {
                          return _ref2.apply(this, arguments);
                        };
                      }());
                    }
                  })["catch"](reject);
                }));

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function signAndSend(_x3) {
        return _signAndSend.apply(this, arguments);
      }

      return signAndSend;
    }()
  }], [{
    key: "isReady",
    value: function isReady() {
      return _isReady;
    }
  }]);

  return AccountManager;
}();

exports["default"] = AccountManager;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yb2Jvbm9taWNzLXN1YnN0cmF0ZS9hY2NvdW50TWFuYWdlci5qcyJdLCJuYW1lcyI6WyJrZXlyaW5nIiwiS2V5cmluZyIsIkVycm9yQWNjb3VudCIsInN0YXR1cyIsInBhcmFtcyIsIkVycm9yIiwiaXNSZWFkeSIsIkFjY291bnRNYW5hZ2VyIiwiY29uZmlnIiwiYXBpIiwiYWNjb3VudCIsImxpc3RlbmVycyIsImtleXMiLCJpdGVtIiwic3VyaSIsIm1ldGEiLCJ0eXBlIiwiYWRkRnJvbVVyaSIsImxlbmd0aCIsInNlbGVjdEFjY291bnRCeUFkZHJlc3MiLCJnZXRBY2NvdW50cyIsImFkZHJlc3MiLCJjYiIsInNldFRpbWVvdXQiLCJvblJlYWR5IiwicGFpcnMiLCJnZXRQYWlycyIsIm1hcCIsInBhaXIiLCJzczU4Rm9ybWF0IiwicmVnaXN0cnkiLCJjaGFpblNTNTgiLCJnZXRQYWlyIiwic2lnbk1zZyIsImRhdGEiLCJQcm9taXNlIiwicmVzb2x2ZSIsInNpZ24iLCJwdXNoIiwiaSIsImluZGV4T2YiLCJzcGxpY2UiLCJ0eCIsIm9wdGlvbnMiLCJyZWplY3QiLCJzaWduQW5kU2VuZCIsImlzSW5qZWN0ZWQiLCJyZXN1bHQiLCJpc0luQmxvY2siLCJldmVudHMiLCJmb3JFYWNoIiwiZXZlbnQiLCJtZXRob2QiLCJzZWN0aW9uIiwicGhhc2UiLCJtZXNzYWdlIiwiaXNNb2R1bGUiLCJtb2QiLCJhc01vZHVsZSIsImZpbmRNZXRhRXJyb3IiLCJkb2NzIiwibmFtZSIsImNvbnNvbGUiLCJsb2ciLCJqb2luIiwicnBjIiwiY2hhaW4iLCJnZXRCbG9jayIsImFzSW5CbG9jayIsInRvU3RyaW5nIiwiYmxvY2siLCJibG9ja051bWJlciIsImhlYWRlciIsIm51bWJlciIsInRvTnVtYmVyIiwidHhJbmRleCIsImFzQXBwbHlFeHRyaW5zaWMiLCJ0b0h1bWFuIiwiaGFzaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUNBOztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLElBQU1BLE9BQU8sR0FBRyxJQUFJQyxZQUFKLEVBQWhCOztJQUVNQyxZOzs7OztBQUNKLDBCQUFzQztBQUFBOztBQUFBLFFBQTFCQyxNQUEwQix1RUFBakIsSUFBaUI7O0FBQUE7O0FBQUEsc0NBQVJDLE1BQVE7QUFBUkEsTUFBQUEsTUFBUTtBQUFBOztBQUNwQyxvREFBU0EsTUFBVDtBQUNBLFVBQUtELE1BQUwsR0FBY0EsTUFBZDtBQUZvQztBQUdyQzs7O2lDQUp3QkUsSzs7QUFPM0IsSUFBSUMsUUFBTyxHQUFHLEtBQWQ7O0lBQ3FCQyxjO0FBQ25CLDRCQUF5QjtBQUFBLFFBQWJDLE1BQWEsdUVBQUosRUFBSTs7QUFBQTs7QUFDdkIsU0FBS0MsR0FBTCxHQUFXLElBQVg7QUFDQSxTQUFLRCxNQUFMLEdBQWNBLE1BQWQ7QUFDQSxTQUFLRSxPQUFMLEdBQWUsSUFBZjtBQUNBLFNBQUtDLFNBQUwsR0FBaUIsRUFBakI7QUFDQUwsSUFBQUEsUUFBTyxHQUFHLElBQVY7QUFDRDs7OztXQUNELHVCQUF1QjtBQUFBLFVBQVhNLElBQVcsdUVBQUosRUFBSTs7QUFBQSxpREFDRkEsSUFERTtBQUFBOztBQUFBO0FBQ3JCLDREQUF5QjtBQUFBLGNBQWRDLElBQWM7QUFDdkIsY0FBSUMsSUFBSSxTQUFSO0FBQ0EsY0FBSUMsSUFBSSxHQUFHLEVBQVg7QUFDQSxjQUFJQyxJQUFJLEdBQUcsS0FBS1IsTUFBTCxDQUFZUSxJQUFaLElBQW9CLFNBQS9COztBQUNBLGNBQUlILElBQUksQ0FBQ0MsSUFBVCxFQUFlO0FBQ2JBLFlBQUFBLElBQUksR0FBR0QsSUFBSSxDQUFDQyxJQUFaOztBQUNBLGdCQUFJRCxJQUFJLENBQUNFLElBQVQsRUFBZTtBQUNiQSxjQUFBQSxJQUFJLEdBQUdGLElBQUksQ0FBQ0UsSUFBWjtBQUNEOztBQUNELGdCQUFJRixJQUFJLENBQUNHLElBQVQsRUFBZTtBQUNiQSxjQUFBQSxJQUFJLEdBQUdILElBQUksQ0FBQ0csSUFBWjtBQUNEO0FBQ0YsV0FSRCxNQVFPO0FBQ0xGLFlBQUFBLElBQUksR0FBR0QsSUFBUDtBQUNEOztBQUNEYixVQUFBQSxPQUFPLENBQUNpQixVQUFSLENBQW1CSCxJQUFuQixFQUF5QkMsSUFBekIsRUFBK0JDLElBQS9CO0FBQ0Q7QUFqQm9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBa0JyQixVQUFJSixJQUFJLENBQUNNLE1BQVQsRUFBaUI7QUFDZixhQUFLQyxzQkFBTCxDQUE0QixLQUFLQyxXQUFMLEdBQW1CLENBQW5CLEVBQXNCQyxPQUFsRDtBQUNEO0FBQ0Y7OztXQUNELGdCQUFPWixHQUFQLEVBQVk7QUFDVixXQUFLQSxHQUFMLEdBQVdBLEdBQVg7QUFDRDs7O1dBSUQsaUJBQVFhLEVBQVIsRUFBWTtBQUFBOztBQUNWLFVBQUloQixRQUFKLEVBQWE7QUFDWGdCLFFBQUFBLEVBQUU7QUFDSCxPQUZELE1BRU87QUFDTEMsUUFBQUEsVUFBVSxDQUFDLFlBQU07QUFDZixVQUFBLE1BQUksQ0FBQ0MsT0FBTCxDQUFhRixFQUFiO0FBQ0QsU0FGUyxFQUVQLElBRk8sQ0FBVjtBQUdEO0FBQ0Y7OztXQUNELHVCQUFjO0FBQUE7O0FBQ1osVUFBTUcsS0FBSyxHQUFHekIsT0FBTyxDQUFDMEIsUUFBUixFQUFkO0FBQ0EsYUFBT0QsS0FBSyxDQUFDRSxHQUFOLENBQVUsVUFBQ0MsSUFBRCxFQUFVO0FBQ3pCLCtDQUNLQSxJQURMO0FBRUVQLFVBQUFBLE9BQU8sRUFBRSwrQkFDUE8sSUFBSSxDQUFDUCxPQURFLEVBRVAsTUFBSSxDQUFDYixNQUFMLENBQVlxQixVQUFaLElBQTBCLE1BQUksQ0FBQ3BCLEdBQUwsQ0FBU3FCLFFBQVQsQ0FBa0JDLFNBRnJDO0FBRlg7QUFPRCxPQVJNLENBQVA7QUFTRDs7Ozs0RkFDRCxrQkFBNkJWLE9BQTdCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDUVgsZ0JBQUFBLE9BRFIsR0FDa0JWLE9BQU8sQ0FBQ2dDLE9BQVIsQ0FBZ0JYLE9BQWhCLENBRGxCO0FBRUUscUJBQUtYLE9BQUwsbUNBQ0tBLE9BREw7QUFFRVcsa0JBQUFBLE9BQU8sRUFBRSwrQkFDUFgsT0FBTyxDQUFDVyxPQURELEVBRVAsS0FBS2IsTUFBTCxDQUFZcUIsVUFBWixJQUEwQixLQUFLcEIsR0FBTCxDQUFTcUIsUUFBVCxDQUFrQkMsU0FGckM7QUFGWDs7QUFPQSxxQkFBS3JCLE9BQUwsQ0FBYXVCLE9BQWI7QUFBQSxxRkFBdUIsaUJBQWdCQyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkRBQ2RDLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQixvQkFBUzFCLE9BQU8sQ0FBQzJCLElBQVIsQ0FBYUgsSUFBYixDQUFULENBQWhCLENBRGM7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXZCOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQVRGLHdEQVltQixLQUFLdkIsU0FaeEI7O0FBQUE7QUFZRSx5RUFBaUM7QUFBdEJXLG9CQUFBQSxFQUFzQjtBQUMvQkEsb0JBQUFBLEVBQUUsQ0FBQyxLQUFLWixPQUFOLENBQUY7QUFDRDtBQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUEsa0RBZVMsS0FBS0EsT0FmZDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPOzs7Ozs7Ozs7O1dBaUJBLGtCQUFTWSxFQUFULEVBQWE7QUFBQTs7QUFDWCxXQUFLWCxTQUFMLENBQWUyQixJQUFmLENBQW9CaEIsRUFBcEI7QUFDQSxhQUFPLFlBQU07QUFDWCxZQUFNaUIsQ0FBQyxHQUFHLE1BQUksQ0FBQzVCLFNBQUwsQ0FBZTZCLE9BQWYsQ0FBdUJsQixFQUF2QixDQUFWOztBQUNBLFFBQUEsTUFBSSxDQUFDWCxTQUFMLENBQWU4QixNQUFmLENBQXNCRixDQUF0QixFQUF5QixDQUF6QjtBQUNELE9BSEQ7QUFJRDs7OztpRkFDRCxrQkFBa0JHLEVBQWxCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXNCQyxnQkFBQUEsT0FBdEIsOERBQWdDLEVBQWhDOztBQUFBLHNCQUNNLEtBQUtqQyxPQUFMLEtBQWlCLElBRHZCO0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQUVVLElBQUlSLFlBQUosQ0FBaUIsQ0FBakIsRUFBb0IscUJBQXBCLENBRlY7O0FBQUE7QUFBQSxrREFJUyxJQUFJaUMsT0FBSixDQUFZLFVBQUNDLE9BQUQsRUFBVVEsTUFBVixFQUFxQjtBQUN0Q0Ysa0JBQUFBLEVBQUUsQ0FBQ0csV0FBSCxDQUNFLE1BQUksQ0FBQ25DLE9BQUwsQ0FBYUssSUFBYixDQUFrQitCLFVBQWxCLEdBQStCLE1BQUksQ0FBQ3BDLE9BQUwsQ0FBYVcsT0FBNUMsR0FBc0QsTUFBSSxDQUFDWCxPQUQ3RCxFQUVFaUMsT0FGRixFQUdFLFVBQUNJLE1BQUQsRUFBWTtBQUNWLHdCQUFJQSxNQUFNLENBQUM1QyxNQUFQLENBQWM2QyxTQUFsQixFQUE2QjtBQUMzQkQsc0JBQUFBLE1BQU0sQ0FBQ0UsTUFBUCxDQUFjQyxPQUFkO0FBQUEsNEZBQXNCLGtCQUFPRCxNQUFQO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrREFJaEJBLE1BSmdCLENBRWxCRSxLQUZrQixFQUVUakIsSUFGUyxpQkFFVEEsSUFGUyxFQUVIa0IsTUFGRyxpQkFFSEEsTUFGRyxFQUVLQyxPQUZMLGlCQUVLQSxPQUZMLEVBR2xCQyxLQUhrQixHQUloQkwsTUFKZ0IsQ0FHbEJLLEtBSGtCOztBQUFBLHdDQUtoQkQsT0FBTyxLQUFLLFFBQVosSUFBd0JELE1BQU0sS0FBSyxpQkFMbkI7QUFBQTtBQUFBO0FBQUE7O0FBTWRHLGtDQUFBQSxPQU5jLEdBTUosT0FOSTs7QUFPbEIsc0NBQUlyQixJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFzQixRQUFaLEVBQXNCO0FBQ2RDLG9DQUFBQSxHQURjLEdBQ1J2QixJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVF3QixRQURBLEVBRXBCOztBQUFBO0FBRm9CLDREQUlsQkQsR0FBRyxDQUFDM0IsUUFBSixDQUFhNkIsYUFBYixDQUEyQkYsR0FBM0IsQ0FKa0IsRUFHWkcsSUFIWSx5QkFHWkEsSUFIWSxFQUdOQyxJQUhNLHlCQUdOQSxJQUhNLEVBR0FSLFFBSEEseUJBR0FBLE9BSEE7QUFLcEJTLG9DQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsSUFBWixFQUFrQlIsUUFBbEIsRUFBMkJPLElBQTNCO0FBQ0FMLG9DQUFBQSxPQUFPLEdBQUdLLElBQUksQ0FBQ0ksSUFBTCxDQUFVLElBQVYsQ0FBVjtBQUNEOztBQWRpQixvRUFlWHBCLE1BQU0sQ0FBQyxJQUFJMUMsWUFBSixDQUFpQixDQUFqQixFQUFvQnFELE9BQXBCLENBQUQsQ0FmSzs7QUFBQTtBQUFBLHdDQWlCbEJGLE9BQU8sS0FBSyxRQUFaLElBQ0FELE1BQU0sS0FBSyxrQkFsQk87QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5Q0FvQkUsTUFBSSxDQUFDM0MsR0FBTCxDQUFTd0QsR0FBVCxDQUFhQyxLQUFiLENBQW1CQyxRQUFuQixDQUNsQnBCLE1BQU0sQ0FBQzVDLE1BQVAsQ0FBY2lFLFNBQWQsQ0FBd0JDLFFBQXhCLEVBRGtCLENBcEJGOztBQUFBO0FBb0JaQyxrQ0FBQUEsS0FwQlk7QUF1QmxCbEMsa0NBQUFBLE9BQU8sQ0FBQztBQUNOa0Msb0NBQUFBLEtBQUssRUFBRXZCLE1BQU0sQ0FBQzVDLE1BQVAsQ0FBY2lFLFNBQWQsQ0FBd0JDLFFBQXhCLEVBREQ7QUFFTkUsb0NBQUFBLFdBQVcsRUFBRUQsS0FBSyxDQUFDQSxLQUFOLENBQVlFLE1BQVosQ0FBbUJDLE1BQW5CLENBQTBCQyxRQUExQixFQUZQO0FBR047QUFDQUMsb0NBQUFBLE9BQU8sRUFBRXJCLEtBQUssQ0FBQ3NCLGdCQUFOLENBQXVCQyxPQUF2QixFQUpIO0FBS05uQyxvQ0FBQUEsRUFBRSxFQUFFQSxFQUFFLENBQUNvQyxJQUFILENBQVFULFFBQVI7QUFMRSxtQ0FBRCxDQUFQOztBQXZCa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXRCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZ0NEO0FBQ0YsbUJBdENILFdBdUNRekIsTUF2Q1I7QUF3Q0QsaUJBekNNLENBSlQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTzs7Ozs7Ozs7OztXQWhEQSxtQkFBaUI7QUFDZixhQUFPdEMsUUFBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2V5cmluZyB9IGZyb20gXCJAcG9sa2Fkb3QvYXBpXCI7XG5pbXBvcnQgeyBlbmNvZGVBZGRyZXNzIH0gZnJvbSBcIkBwb2xrYWRvdC91dGlsLWNyeXB0b1wiO1xuaW1wb3J0IHsgdThhVG9IZXggfSBmcm9tIFwiQHBvbGthZG90L3V0aWxcIjtcblxuY29uc3Qga2V5cmluZyA9IG5ldyBLZXlyaW5nKCk7XG5cbmNsYXNzIEVycm9yQWNjb3VudCBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3Ioc3RhdHVzID0gbnVsbCwgLi4ucGFyYW1zKSB7XG4gICAgc3VwZXIoLi4ucGFyYW1zKTtcbiAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgfVxufVxuXG5sZXQgaXNSZWFkeSA9IGZhbHNlO1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQWNjb3VudE1hbmFnZXIge1xuICBjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuICAgIHRoaXMuYXBpID0gbnVsbDtcbiAgICB0aGlzLmNvbmZpZyA9IGNvbmZpZztcbiAgICB0aGlzLmFjY291bnQgPSBudWxsO1xuICAgIHRoaXMubGlzdGVuZXJzID0gW107XG4gICAgaXNSZWFkeSA9IHRydWU7XG4gIH1cbiAgc2V0QWNjb3VudHMoa2V5cyA9IFtdKSB7XG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGtleXMpIHtcbiAgICAgIGxldCBzdXJpO1xuICAgICAgbGV0IG1ldGEgPSB7fTtcbiAgICAgIGxldCB0eXBlID0gdGhpcy5jb25maWcudHlwZSB8fCBcInNyMjU1MTlcIjtcbiAgICAgIGlmIChpdGVtLnN1cmkpIHtcbiAgICAgICAgc3VyaSA9IGl0ZW0uc3VyaTtcbiAgICAgICAgaWYgKGl0ZW0ubWV0YSkge1xuICAgICAgICAgIG1ldGEgPSBpdGVtLm1ldGE7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGl0ZW0udHlwZSkge1xuICAgICAgICAgIHR5cGUgPSBpdGVtLnR5cGU7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN1cmkgPSBpdGVtO1xuICAgICAgfVxuICAgICAga2V5cmluZy5hZGRGcm9tVXJpKHN1cmksIG1ldGEsIHR5cGUpO1xuICAgIH1cbiAgICBpZiAoa2V5cy5sZW5ndGgpIHtcbiAgICAgIHRoaXMuc2VsZWN0QWNjb3VudEJ5QWRkcmVzcyh0aGlzLmdldEFjY291bnRzKClbMF0uYWRkcmVzcyk7XG4gICAgfVxuICB9XG4gIHNldEFwaShhcGkpIHtcbiAgICB0aGlzLmFwaSA9IGFwaTtcbiAgfVxuICBzdGF0aWMgaXNSZWFkeSgpIHtcbiAgICByZXR1cm4gaXNSZWFkeTtcbiAgfVxuICBvblJlYWR5KGNiKSB7XG4gICAgaWYgKGlzUmVhZHkpIHtcbiAgICAgIGNiKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLm9uUmVhZHkoY2IpO1xuICAgICAgfSwgMTAwMCk7XG4gICAgfVxuICB9XG4gIGdldEFjY291bnRzKCkge1xuICAgIGNvbnN0IHBhaXJzID0ga2V5cmluZy5nZXRQYWlycygpO1xuICAgIHJldHVybiBwYWlycy5tYXAoKHBhaXIpID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnBhaXIsXG4gICAgICAgIGFkZHJlc3M6IGVuY29kZUFkZHJlc3MoXG4gICAgICAgICAgcGFpci5hZGRyZXNzLFxuICAgICAgICAgIHRoaXMuY29uZmlnLnNzNThGb3JtYXQgfHwgdGhpcy5hcGkucmVnaXN0cnkuY2hhaW5TUzU4XG4gICAgICAgICksXG4gICAgICB9O1xuICAgIH0pO1xuICB9XG4gIGFzeW5jIHNlbGVjdEFjY291bnRCeUFkZHJlc3MoYWRkcmVzcykge1xuICAgIGNvbnN0IGFjY291bnQgPSBrZXlyaW5nLmdldFBhaXIoYWRkcmVzcyk7XG4gICAgdGhpcy5hY2NvdW50ID0ge1xuICAgICAgLi4uYWNjb3VudCxcbiAgICAgIGFkZHJlc3M6IGVuY29kZUFkZHJlc3MoXG4gICAgICAgIGFjY291bnQuYWRkcmVzcyxcbiAgICAgICAgdGhpcy5jb25maWcuc3M1OEZvcm1hdCB8fCB0aGlzLmFwaS5yZWdpc3RyeS5jaGFpblNTNThcbiAgICAgICksXG4gICAgfTtcbiAgICB0aGlzLmFjY291bnQuc2lnbk1zZyA9IGFzeW5jIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHU4YVRvSGV4KGFjY291bnQuc2lnbihkYXRhKSkpO1xuICAgIH07XG4gICAgZm9yIChjb25zdCBjYiBvZiB0aGlzLmxpc3RlbmVycykge1xuICAgICAgY2IodGhpcy5hY2NvdW50KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuYWNjb3VudDtcbiAgfVxuICBvbkNoYW5nZShjYikge1xuICAgIHRoaXMubGlzdGVuZXJzLnB1c2goY2IpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjb25zdCBpID0gdGhpcy5saXN0ZW5lcnMuaW5kZXhPZihjYik7XG4gICAgICB0aGlzLmxpc3RlbmVycy5zcGxpY2UoaSwgMSk7XG4gICAgfTtcbiAgfVxuICBhc3luYyBzaWduQW5kU2VuZCh0eCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKHRoaXMuYWNjb3VudCA9PT0gbnVsbCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yQWNjb3VudCgzLCBcIk5vIGFjY291bnQgc2VsZWN0ZWRcIik7XG4gICAgfVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0eC5zaWduQW5kU2VuZChcbiAgICAgICAgdGhpcy5hY2NvdW50Lm1ldGEuaXNJbmplY3RlZCA/IHRoaXMuYWNjb3VudC5hZGRyZXNzIDogdGhpcy5hY2NvdW50LFxuICAgICAgICBvcHRpb25zLFxuICAgICAgICAocmVzdWx0KSA9PiB7XG4gICAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMuaXNJbkJsb2NrKSB7XG4gICAgICAgICAgICByZXN1bHQuZXZlbnRzLmZvckVhY2goYXN5bmMgKGV2ZW50cykgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICAgICAgZXZlbnQ6IHsgZGF0YSwgbWV0aG9kLCBzZWN0aW9uIH0sXG4gICAgICAgICAgICAgICAgcGhhc2UsXG4gICAgICAgICAgICAgIH0gPSBldmVudHM7XG4gICAgICAgICAgICAgIGlmIChzZWN0aW9uID09PSBcInN5c3RlbVwiICYmIG1ldGhvZCA9PT0gXCJFeHRyaW5zaWNGYWlsZWRcIikge1xuICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gXCJFcnJvclwiO1xuICAgICAgICAgICAgICAgIGlmIChkYXRhWzBdLmlzTW9kdWxlKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBtb2QgPSBkYXRhWzBdLmFzTW9kdWxlO1xuICAgICAgICAgICAgICAgICAgLy8gY29uc3QgbW9kID0gcmVzdWx0LmRpc3BhdGNoRXJyb3IuYXNNb2R1bGU7XG4gICAgICAgICAgICAgICAgICBjb25zdCB7IGRvY3MsIG5hbWUsIHNlY3Rpb24gfSA9XG4gICAgICAgICAgICAgICAgICAgIG1vZC5yZWdpc3RyeS5maW5kTWV0YUVycm9yKG1vZCk7XG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhuYW1lLCBzZWN0aW9uLCBkb2NzKTtcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBkb2NzLmpvaW4oXCIsIFwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdChuZXcgRXJyb3JBY2NvdW50KDQsIG1lc3NhZ2UpKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICBzZWN0aW9uID09PSBcInN5c3RlbVwiICYmXG4gICAgICAgICAgICAgICAgbWV0aG9kID09PSBcIkV4dHJpbnNpY1N1Y2Nlc3NcIlxuICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBibG9jayA9IGF3YWl0IHRoaXMuYXBpLnJwYy5jaGFpbi5nZXRCbG9jayhcbiAgICAgICAgICAgICAgICAgIHJlc3VsdC5zdGF0dXMuYXNJbkJsb2NrLnRvU3RyaW5nKClcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgYmxvY2s6IHJlc3VsdC5zdGF0dXMuYXNJbkJsb2NrLnRvU3RyaW5nKCksXG4gICAgICAgICAgICAgICAgICBibG9ja051bWJlcjogYmxvY2suYmxvY2suaGVhZGVyLm51bWJlci50b051bWJlcigpLFxuICAgICAgICAgICAgICAgICAgLy8gY29uc3QgaW5kZXggPSBwaGFzZS52YWx1ZS50b051bWJlcigpO1xuICAgICAgICAgICAgICAgICAgdHhJbmRleDogcGhhc2UuYXNBcHBseUV4dHJpbnNpYy50b0h1bWFuKCksXG4gICAgICAgICAgICAgICAgICB0eDogdHguaGFzaC50b1N0cmluZygpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICkuY2F0Y2gocmVqZWN0KTtcbiAgICB9KTtcbiAgfVxufVxuIl19