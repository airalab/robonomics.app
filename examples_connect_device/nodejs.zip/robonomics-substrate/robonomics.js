"use strict";

require("core-js/modules/es.promise.js");

require("core-js/modules/es.array.from.js");

require("core-js/modules/es.string.iterator.js");

require("core-js/modules/es.symbol.js");

require("core-js/modules/es.symbol.description.js");

require("core-js/modules/es.symbol.iterator.js");

require("core-js/modules/es.array.iterator.js");

require("core-js/modules/web.dom-collections.iterator.js");

require("core-js/modules/es.array.is-array.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

require("regenerator-runtime/runtime.js");

require("core-js/modules/es.function.name.js");

require("core-js/modules/web.timers.js");

require("core-js/modules/es.array.for-each.js");

require("core-js/modules/web.dom-collections.for-each.js");

require("core-js/modules/es.date.to-string.js");

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.regexp.to-string.js");

require("core-js/modules/es.array.slice.js");

require("core-js/modules/es.object.values.js");

require("core-js/modules/es.array.filter.js");

require("core-js/modules/es.object.define-property.js");

var _api = require("@polkadot/api");

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var instances = {};

var Robonomics = /*#__PURE__*/function () {
  function Robonomics(config) {
    _classCallCheck(this, Robonomics);

    this.config = config;
    this.api = null;
    this.provider = null;
    this.accountManager = null;
    this.isReady = false;
    this.modules = this.config.modules || ["datalog", "launch"];
    instances[config.name || config.endpoint] = this;
    this.init();
  }

  _createClass(Robonomics, [{
    key: "createProvider",
    value: function createProvider(endpoint) {
      this.provider = new _api.WsProvider(endpoint);
    }
  }, {
    key: "createApi",
    value: function () {
      var _createApi = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(types) {
        var _iterator, _step, name, module;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _api.ApiPromise.create({
                  provider: this.provider,
                  types: types
                });

              case 2:
                this.api = _context.sent;
                _iterator = _createForOfIteratorHelper(this.modules);

                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    name = _step.value;
                    module = require("./modules/".concat(name));
                    this[name] = new module["default"](this);
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function createApi(_x) {
        return _createApi.apply(this, arguments);
      }

      return createApi;
    }()
  }, {
    key: "onReady",
    value: function onReady(cb) {
      var _this = this;

      if (this.isReady) {
        cb();
      } else {
        setTimeout(function () {
          _this.onReady(cb);
        }, 100);
      }
    }
  }, {
    key: "init",
    value: function () {
      var _init = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!this.api) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return");

              case 2:
                this.createProvider(this.config.endpoint);
                _context2.next = 5;
                return this.createApi(this.config.types);

              case 5:
                this.isReady = true;

                if (this.accountManager && this.accountManager.api === null) {
                  this.accountManager.setApi(this.api);
                }

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function init() {
        return _init.apply(this, arguments);
      }

      return init;
    }()
  }, {
    key: "setAccountManager",
    value: function setAccountManager(accountManager) {
      if (this.api) {
        accountManager.setApi(this.api);
      }

      this.accountManager = accountManager;
    }
  }, {
    key: "onBlock",
    value: function () {
      var _onBlock = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(cb) {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.api.rpc.chain.subscribeNewHeads(function (header) {
                  cb(header.number.toNumber());
                });

              case 2:
                return _context3.abrupt("return", _context3.sent);

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onBlock(_x2) {
        return _onBlock.apply(this, arguments);
      }

      return onBlock;
    }()
  }, {
    key: "on",
    value: function () {
      var _on = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var filter,
            cb,
            _args4 = arguments;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                filter = _args4.length > 0 && _args4[0] !== undefined ? _args4[0] : {};
                cb = _args4.length > 1 ? _args4[1] : undefined;
                _context4.next = 4;
                return this.api.query.system.events(function (events) {
                  // this.api.rpc.chain.getHeader(events.createdAtHash, (header) => {
                  //   const blockNumber = header.number.toNumber();
                  //   // const blockHash = header.hash.toHex();
                  //   console.log(blockNumber);
                  // });
                  var result = {};
                  events.forEach(function (record) {
                    var event = record.event,
                        phase = record.phase;

                    if (phase.isNull) {
                      return;
                    }

                    var index = phase.value.toNumber();

                    if (event.section === filter.section && (!filter.method || event.method === filter.method)) {
                      result[index] = {
                        event: event.method,
                        account: event.data[0].toString(),
                        success: null,
                        data: event.data.slice(1)
                      };
                    }

                    if (event.section === "system" && result[index]) {
                      if (event.method === "ExtrinsicSuccess") {
                        result[index].success = true;
                      } else if (event.method === "ExtrinsicFailed") {
                        result[index].success = false;
                      }
                    }
                  });
                  result = Object.values(result);

                  if (filter.account && result.length) {
                    result = result.filter(function (item) {
                      if (item.account === filter.account) {
                        return true;
                      }

                      return false;
                    });
                  }

                  if (result.length) {
                    cb(result);
                  }
                });

              case 4:
                return _context4.abrupt("return", _context4.sent);

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function on() {
        return _on.apply(this, arguments);
      }

      return on;
    }()
  }], [{
    key: "getInstance",
    value: function getInstance() {
      var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (name === null) {
        var instancesArray = Object.values(instances);

        if (instancesArray.length > 0) {
          return instancesArray[0];
        }
      }

      if (instances[name]) {
        return instances[name];
      }

      throw new Error("Instance named ".concat(name, " not found"));
    }
  }]);

  return Robonomics;
}();

exports["default"] = Robonomics;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yb2Jvbm9taWNzLXN1YnN0cmF0ZS9yb2Jvbm9taWNzLmpzIl0sIm5hbWVzIjpbImluc3RhbmNlcyIsIlJvYm9ub21pY3MiLCJjb25maWciLCJhcGkiLCJwcm92aWRlciIsImFjY291bnRNYW5hZ2VyIiwiaXNSZWFkeSIsIm1vZHVsZXMiLCJuYW1lIiwiZW5kcG9pbnQiLCJpbml0IiwiV3NQcm92aWRlciIsInR5cGVzIiwiQXBpUHJvbWlzZSIsImNyZWF0ZSIsIm1vZHVsZSIsInJlcXVpcmUiLCJjYiIsInNldFRpbWVvdXQiLCJvblJlYWR5IiwiY3JlYXRlUHJvdmlkZXIiLCJjcmVhdGVBcGkiLCJzZXRBcGkiLCJycGMiLCJjaGFpbiIsInN1YnNjcmliZU5ld0hlYWRzIiwiaGVhZGVyIiwibnVtYmVyIiwidG9OdW1iZXIiLCJmaWx0ZXIiLCJxdWVyeSIsInN5c3RlbSIsImV2ZW50cyIsInJlc3VsdCIsImZvckVhY2giLCJyZWNvcmQiLCJldmVudCIsInBoYXNlIiwiaXNOdWxsIiwiaW5kZXgiLCJ2YWx1ZSIsInNlY3Rpb24iLCJtZXRob2QiLCJhY2NvdW50IiwiZGF0YSIsInRvU3RyaW5nIiwic3VjY2VzcyIsInNsaWNlIiwiT2JqZWN0IiwidmFsdWVzIiwibGVuZ3RoIiwiaXRlbSIsImluc3RhbmNlc0FycmF5IiwiRXJyb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsSUFBTUEsU0FBUyxHQUFHLEVBQWxCOztJQUVxQkMsVTtBQUNuQixzQkFBWUMsTUFBWixFQUFvQjtBQUFBOztBQUNsQixTQUFLQSxNQUFMLEdBQWNBLE1BQWQ7QUFDQSxTQUFLQyxHQUFMLEdBQVcsSUFBWDtBQUNBLFNBQUtDLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxTQUFLQyxjQUFMLEdBQXNCLElBQXRCO0FBQ0EsU0FBS0MsT0FBTCxHQUFlLEtBQWY7QUFDQSxTQUFLQyxPQUFMLEdBQWUsS0FBS0wsTUFBTCxDQUFZSyxPQUFaLElBQXVCLENBQUMsU0FBRCxFQUFZLFFBQVosQ0FBdEM7QUFDQVAsSUFBQUEsU0FBUyxDQUFDRSxNQUFNLENBQUNNLElBQVAsSUFBZU4sTUFBTSxDQUFDTyxRQUF2QixDQUFULEdBQTRDLElBQTVDO0FBQ0EsU0FBS0MsSUFBTDtBQUNEOzs7O1dBYUQsd0JBQWVELFFBQWYsRUFBeUI7QUFDdkIsV0FBS0wsUUFBTCxHQUFnQixJQUFJTyxlQUFKLENBQWVGLFFBQWYsQ0FBaEI7QUFDRDs7OzsrRUFDRCxpQkFBZ0JHLEtBQWhCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUNtQkMsZ0JBQVdDLE1BQVgsQ0FBa0I7QUFDakNWLGtCQUFBQSxRQUFRLEVBQUUsS0FBS0EsUUFEa0I7QUFFakNRLGtCQUFBQSxLQUFLLEVBQUVBO0FBRjBCLGlCQUFsQixDQURuQjs7QUFBQTtBQUNFLHFCQUFLVCxHQURQO0FBQUEsdURBS3FCLEtBQUtJLE9BTDFCOztBQUFBO0FBS0Usc0VBQWlDO0FBQXRCQyxvQkFBQUEsSUFBc0I7QUFDekJPLG9CQUFBQSxNQUR5QixHQUNoQkMsT0FBTyxxQkFBY1IsSUFBZCxFQURTO0FBRS9CLHlCQUFLQSxJQUFMLElBQWEsSUFBSU8sTUFBTSxXQUFWLENBQW1CLElBQW5CLENBQWI7QUFDRDtBQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTzs7Ozs7Ozs7OztXQVVBLGlCQUFRRSxFQUFSLEVBQVk7QUFBQTs7QUFDVixVQUFJLEtBQUtYLE9BQVQsRUFBa0I7QUFDaEJXLFFBQUFBLEVBQUU7QUFDSCxPQUZELE1BRU87QUFDTEMsUUFBQUEsVUFBVSxDQUFDLFlBQU07QUFDZixVQUFBLEtBQUksQ0FBQ0MsT0FBTCxDQUFhRixFQUFiO0FBQ0QsU0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdEO0FBQ0Y7Ozs7MEVBQ0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNNLEtBQUtkLEdBRFg7QUFBQTtBQUFBO0FBQUE7O0FBQUE7O0FBQUE7QUFJRSxxQkFBS2lCLGNBQUwsQ0FBb0IsS0FBS2xCLE1BQUwsQ0FBWU8sUUFBaEM7QUFKRjtBQUFBLHVCQUtRLEtBQUtZLFNBQUwsQ0FBZSxLQUFLbkIsTUFBTCxDQUFZVSxLQUEzQixDQUxSOztBQUFBO0FBTUUscUJBQUtOLE9BQUwsR0FBZSxJQUFmOztBQUNBLG9CQUFJLEtBQUtELGNBQUwsSUFBdUIsS0FBS0EsY0FBTCxDQUFvQkYsR0FBcEIsS0FBNEIsSUFBdkQsRUFBNkQ7QUFDM0QsdUJBQUtFLGNBQUwsQ0FBb0JpQixNQUFwQixDQUEyQixLQUFLbkIsR0FBaEM7QUFDRDs7QUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPOzs7Ozs7Ozs7O1dBV0EsMkJBQWtCRSxjQUFsQixFQUFrQztBQUNoQyxVQUFJLEtBQUtGLEdBQVQsRUFBYztBQUNaRSxRQUFBQSxjQUFjLENBQUNpQixNQUFmLENBQXNCLEtBQUtuQixHQUEzQjtBQUNEOztBQUNELFdBQUtFLGNBQUwsR0FBc0JBLGNBQXRCO0FBQ0Q7Ozs7NkVBQ0Qsa0JBQWNZLEVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ2UsS0FBS2QsR0FBTCxDQUFTb0IsR0FBVCxDQUFhQyxLQUFiLENBQW1CQyxpQkFBbkIsQ0FBcUMsVUFBQ0MsTUFBRCxFQUFZO0FBQzVEVCxrQkFBQUEsRUFBRSxDQUFDUyxNQUFNLENBQUNDLE1BQVAsQ0FBY0MsUUFBZCxFQUFELENBQUY7QUFDRCxpQkFGWSxDQURmOztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTzs7Ozs7Ozs7Ozs7d0VBS0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFTQyxnQkFBQUEsTUFBVCw4REFBa0IsRUFBbEI7QUFBc0JaLGdCQUFBQSxFQUF0QjtBQUFBO0FBQUEsdUJBQ2UsS0FBS2QsR0FBTCxDQUFTMkIsS0FBVCxDQUFlQyxNQUFmLENBQXNCQyxNQUF0QixDQUE2QixVQUFDQSxNQUFELEVBQVk7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFJQyxNQUFNLEdBQUcsRUFBYjtBQUNBRCxrQkFBQUEsTUFBTSxDQUFDRSxPQUFQLENBQWUsVUFBQ0MsTUFBRCxFQUFZO0FBQ3pCLHdCQUFRQyxLQUFSLEdBQXlCRCxNQUF6QixDQUFRQyxLQUFSO0FBQUEsd0JBQWVDLEtBQWYsR0FBeUJGLE1BQXpCLENBQWVFLEtBQWY7O0FBQ0Esd0JBQUlBLEtBQUssQ0FBQ0MsTUFBVixFQUFrQjtBQUNoQjtBQUNEOztBQUNELHdCQUFNQyxLQUFLLEdBQUdGLEtBQUssQ0FBQ0csS0FBTixDQUFZWixRQUFaLEVBQWQ7O0FBQ0Esd0JBQ0VRLEtBQUssQ0FBQ0ssT0FBTixLQUFrQlosTUFBTSxDQUFDWSxPQUF6QixLQUNDLENBQUNaLE1BQU0sQ0FBQ2EsTUFBUixJQUFrQk4sS0FBSyxDQUFDTSxNQUFOLEtBQWlCYixNQUFNLENBQUNhLE1BRDNDLENBREYsRUFHRTtBQUNBVCxzQkFBQUEsTUFBTSxDQUFDTSxLQUFELENBQU4sR0FBZ0I7QUFDZEgsd0JBQUFBLEtBQUssRUFBRUEsS0FBSyxDQUFDTSxNQURDO0FBRWRDLHdCQUFBQSxPQUFPLEVBQUVQLEtBQUssQ0FBQ1EsSUFBTixDQUFXLENBQVgsRUFBY0MsUUFBZCxFQUZLO0FBR2RDLHdCQUFBQSxPQUFPLEVBQUUsSUFISztBQUlkRix3QkFBQUEsSUFBSSxFQUFFUixLQUFLLENBQUNRLElBQU4sQ0FBV0csS0FBWCxDQUFpQixDQUFqQjtBQUpRLHVCQUFoQjtBQU1EOztBQUNELHdCQUFJWCxLQUFLLENBQUNLLE9BQU4sS0FBa0IsUUFBbEIsSUFBOEJSLE1BQU0sQ0FBQ00sS0FBRCxDQUF4QyxFQUFpRDtBQUMvQywwQkFBSUgsS0FBSyxDQUFDTSxNQUFOLEtBQWlCLGtCQUFyQixFQUF5QztBQUN2Q1Qsd0JBQUFBLE1BQU0sQ0FBQ00sS0FBRCxDQUFOLENBQWNPLE9BQWQsR0FBd0IsSUFBeEI7QUFDRCx1QkFGRCxNQUVPLElBQUlWLEtBQUssQ0FBQ00sTUFBTixLQUFpQixpQkFBckIsRUFBd0M7QUFDN0NULHdCQUFBQSxNQUFNLENBQUNNLEtBQUQsQ0FBTixDQUFjTyxPQUFkLEdBQXdCLEtBQXhCO0FBQ0Q7QUFDRjtBQUNGLG1CQXhCRDtBQXlCQWIsa0JBQUFBLE1BQU0sR0FBR2UsTUFBTSxDQUFDQyxNQUFQLENBQWNoQixNQUFkLENBQVQ7O0FBQ0Esc0JBQUlKLE1BQU0sQ0FBQ2MsT0FBUCxJQUFrQlYsTUFBTSxDQUFDaUIsTUFBN0IsRUFBcUM7QUFDbkNqQixvQkFBQUEsTUFBTSxHQUFHQSxNQUFNLENBQUNKLE1BQVAsQ0FBYyxVQUFDc0IsSUFBRCxFQUFVO0FBQy9CLDBCQUFJQSxJQUFJLENBQUNSLE9BQUwsS0FBaUJkLE1BQU0sQ0FBQ2MsT0FBNUIsRUFBcUM7QUFDbkMsK0JBQU8sSUFBUDtBQUNEOztBQUNELDZCQUFPLEtBQVA7QUFDRCxxQkFMUSxDQUFUO0FBTUQ7O0FBQ0Qsc0JBQUlWLE1BQU0sQ0FBQ2lCLE1BQVgsRUFBbUI7QUFDakJqQyxvQkFBQUEsRUFBRSxDQUFDZ0IsTUFBRCxDQUFGO0FBQ0Q7QUFDRixpQkE1Q1ksQ0FEZjs7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE87Ozs7Ozs7Ozs7V0F4REEsdUJBQWdDO0FBQUEsVUFBYnpCLElBQWEsdUVBQU4sSUFBTTs7QUFDOUIsVUFBSUEsSUFBSSxLQUFLLElBQWIsRUFBbUI7QUFDakIsWUFBTTRDLGNBQWMsR0FBR0osTUFBTSxDQUFDQyxNQUFQLENBQWNqRCxTQUFkLENBQXZCOztBQUNBLFlBQUlvRCxjQUFjLENBQUNGLE1BQWYsR0FBd0IsQ0FBNUIsRUFBK0I7QUFDN0IsaUJBQU9FLGNBQWMsQ0FBQyxDQUFELENBQXJCO0FBQ0Q7QUFDRjs7QUFDRCxVQUFJcEQsU0FBUyxDQUFDUSxJQUFELENBQWIsRUFBcUI7QUFDbkIsZUFBT1IsU0FBUyxDQUFDUSxJQUFELENBQWhCO0FBQ0Q7O0FBQ0QsWUFBTSxJQUFJNkMsS0FBSiwwQkFBNEI3QyxJQUE1QixnQkFBTjtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBpUHJvbWlzZSwgV3NQcm92aWRlciB9IGZyb20gXCJAcG9sa2Fkb3QvYXBpXCI7XG5cbmNvbnN0IGluc3RhbmNlcyA9IHt9O1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSb2Jvbm9taWNzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgdGhpcy5hcGkgPSBudWxsO1xuICAgIHRoaXMucHJvdmlkZXIgPSBudWxsO1xuICAgIHRoaXMuYWNjb3VudE1hbmFnZXIgPSBudWxsO1xuICAgIHRoaXMuaXNSZWFkeSA9IGZhbHNlO1xuICAgIHRoaXMubW9kdWxlcyA9IHRoaXMuY29uZmlnLm1vZHVsZXMgfHwgW1wiZGF0YWxvZ1wiLCBcImxhdW5jaFwiXTtcbiAgICBpbnN0YW5jZXNbY29uZmlnLm5hbWUgfHwgY29uZmlnLmVuZHBvaW50XSA9IHRoaXM7XG4gICAgdGhpcy5pbml0KCk7XG4gIH1cbiAgc3RhdGljIGdldEluc3RhbmNlKG5hbWUgPSBudWxsKSB7XG4gICAgaWYgKG5hbWUgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IGluc3RhbmNlc0FycmF5ID0gT2JqZWN0LnZhbHVlcyhpbnN0YW5jZXMpO1xuICAgICAgaWYgKGluc3RhbmNlc0FycmF5Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgcmV0dXJuIGluc3RhbmNlc0FycmF5WzBdO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaW5zdGFuY2VzW25hbWVdKSB7XG4gICAgICByZXR1cm4gaW5zdGFuY2VzW25hbWVdO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoYEluc3RhbmNlIG5hbWVkICR7bmFtZX0gbm90IGZvdW5kYCk7XG4gIH1cbiAgY3JlYXRlUHJvdmlkZXIoZW5kcG9pbnQpIHtcbiAgICB0aGlzLnByb3ZpZGVyID0gbmV3IFdzUHJvdmlkZXIoZW5kcG9pbnQpO1xuICB9XG4gIGFzeW5jIGNyZWF0ZUFwaSh0eXBlcykge1xuICAgIHRoaXMuYXBpID0gYXdhaXQgQXBpUHJvbWlzZS5jcmVhdGUoe1xuICAgICAgcHJvdmlkZXI6IHRoaXMucHJvdmlkZXIsXG4gICAgICB0eXBlczogdHlwZXMsXG4gICAgfSk7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIHRoaXMubW9kdWxlcykge1xuICAgICAgY29uc3QgbW9kdWxlID0gcmVxdWlyZShgLi9tb2R1bGVzLyR7bmFtZX1gKTtcbiAgICAgIHRoaXNbbmFtZV0gPSBuZXcgbW9kdWxlLmRlZmF1bHQodGhpcyk7XG4gICAgfVxuICB9XG4gIG9uUmVhZHkoY2IpIHtcbiAgICBpZiAodGhpcy5pc1JlYWR5KSB7XG4gICAgICBjYigpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5vblJlYWR5KGNiKTtcbiAgICAgIH0sIDEwMCk7XG4gICAgfVxuICB9XG4gIGFzeW5jIGluaXQoKSB7XG4gICAgaWYgKHRoaXMuYXBpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuY3JlYXRlUHJvdmlkZXIodGhpcy5jb25maWcuZW5kcG9pbnQpO1xuICAgIGF3YWl0IHRoaXMuY3JlYXRlQXBpKHRoaXMuY29uZmlnLnR5cGVzKTtcbiAgICB0aGlzLmlzUmVhZHkgPSB0cnVlO1xuICAgIGlmICh0aGlzLmFjY291bnRNYW5hZ2VyICYmIHRoaXMuYWNjb3VudE1hbmFnZXIuYXBpID09PSBudWxsKSB7XG4gICAgICB0aGlzLmFjY291bnRNYW5hZ2VyLnNldEFwaSh0aGlzLmFwaSk7XG4gICAgfVxuICB9XG4gIHNldEFjY291bnRNYW5hZ2VyKGFjY291bnRNYW5hZ2VyKSB7XG4gICAgaWYgKHRoaXMuYXBpKSB7XG4gICAgICBhY2NvdW50TWFuYWdlci5zZXRBcGkodGhpcy5hcGkpO1xuICAgIH1cbiAgICB0aGlzLmFjY291bnRNYW5hZ2VyID0gYWNjb3VudE1hbmFnZXI7XG4gIH1cbiAgYXN5bmMgb25CbG9jayhjYikge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmFwaS5ycGMuY2hhaW4uc3Vic2NyaWJlTmV3SGVhZHMoKGhlYWRlcikgPT4ge1xuICAgICAgY2IoaGVhZGVyLm51bWJlci50b051bWJlcigpKTtcbiAgICB9KTtcbiAgfVxuICBhc3luYyBvbihmaWx0ZXIgPSB7fSwgY2IpIHtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5hcGkucXVlcnkuc3lzdGVtLmV2ZW50cygoZXZlbnRzKSA9PiB7XG4gICAgICAvLyB0aGlzLmFwaS5ycGMuY2hhaW4uZ2V0SGVhZGVyKGV2ZW50cy5jcmVhdGVkQXRIYXNoLCAoaGVhZGVyKSA9PiB7XG4gICAgICAvLyAgIGNvbnN0IGJsb2NrTnVtYmVyID0gaGVhZGVyLm51bWJlci50b051bWJlcigpO1xuICAgICAgLy8gICAvLyBjb25zdCBibG9ja0hhc2ggPSBoZWFkZXIuaGFzaC50b0hleCgpO1xuICAgICAgLy8gICBjb25zb2xlLmxvZyhibG9ja051bWJlcik7XG4gICAgICAvLyB9KTtcbiAgICAgIGxldCByZXN1bHQgPSB7fTtcbiAgICAgIGV2ZW50cy5mb3JFYWNoKChyZWNvcmQpID0+IHtcbiAgICAgICAgY29uc3QgeyBldmVudCwgcGhhc2UgfSA9IHJlY29yZDtcbiAgICAgICAgaWYgKHBoYXNlLmlzTnVsbCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbmRleCA9IHBoYXNlLnZhbHVlLnRvTnVtYmVyKCk7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBldmVudC5zZWN0aW9uID09PSBmaWx0ZXIuc2VjdGlvbiAmJlxuICAgICAgICAgICghZmlsdGVyLm1ldGhvZCB8fCBldmVudC5tZXRob2QgPT09IGZpbHRlci5tZXRob2QpXG4gICAgICAgICkge1xuICAgICAgICAgIHJlc3VsdFtpbmRleF0gPSB7XG4gICAgICAgICAgICBldmVudDogZXZlbnQubWV0aG9kLFxuICAgICAgICAgICAgYWNjb3VudDogZXZlbnQuZGF0YVswXS50b1N0cmluZygpLFxuICAgICAgICAgICAgc3VjY2VzczogbnVsbCxcbiAgICAgICAgICAgIGRhdGE6IGV2ZW50LmRhdGEuc2xpY2UoMSksXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZXZlbnQuc2VjdGlvbiA9PT0gXCJzeXN0ZW1cIiAmJiByZXN1bHRbaW5kZXhdKSB7XG4gICAgICAgICAgaWYgKGV2ZW50Lm1ldGhvZCA9PT0gXCJFeHRyaW5zaWNTdWNjZXNzXCIpIHtcbiAgICAgICAgICAgIHJlc3VsdFtpbmRleF0uc3VjY2VzcyA9IHRydWU7XG4gICAgICAgICAgfSBlbHNlIGlmIChldmVudC5tZXRob2QgPT09IFwiRXh0cmluc2ljRmFpbGVkXCIpIHtcbiAgICAgICAgICAgIHJlc3VsdFtpbmRleF0uc3VjY2VzcyA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXN1bHQgPSBPYmplY3QudmFsdWVzKHJlc3VsdCk7XG4gICAgICBpZiAoZmlsdGVyLmFjY291bnQgJiYgcmVzdWx0Lmxlbmd0aCkge1xuICAgICAgICByZXN1bHQgPSByZXN1bHQuZmlsdGVyKChpdGVtKSA9PiB7XG4gICAgICAgICAgaWYgKGl0ZW0uYWNjb3VudCA9PT0gZmlsdGVyLmFjY291bnQpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaWYgKHJlc3VsdC5sZW5ndGgpIHtcbiAgICAgICAgY2IocmVzdWx0KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuIl19