"use strict";

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.promise.js");

require("regenerator-runtime/runtime.js");

var _polkadot = _interopRequireDefault(require("./polkadot"));

var _pubsub = _interopRequireDefault(require("./pubsub"));

var _config = _interopRequireDefault(require("./config.json"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

_asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
  return regeneratorRuntime.wrap(function _callee$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          if (!_config["default"].polkadot.enable) {
            _context.next = 3;
            break;
          }

          _context.next = 3;
          return (0, _polkadot["default"])();

        case 3:
          if (_config["default"].pubsub.enable) {
            (0, _pubsub["default"])();
          }

        case 4:
        case "end":
          return _context.stop();
      }
    }
  }, _callee);
}))();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9pbmRleC5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJwb2xrYWRvdCIsImVuYWJsZSIsInB1YnN1YiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7QUFDQTs7QUFDQTs7Ozs7Ozs7QUFFQSx3REFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFDS0EsbUJBQU9DLFFBQVAsQ0FBZ0JDLE1BRHJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsaUJBRVMsMkJBRlQ7O0FBQUE7QUFJQyxjQUFJRixtQkFBT0csTUFBUCxDQUFjRCxNQUFsQixFQUEwQjtBQUN4QjtBQUNEOztBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLENBQUQiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgcG9sa2Fkb3QgZnJvbSBcIi4vcG9sa2Fkb3RcIjtcbmltcG9ydCBwdWJzdWIgZnJvbSBcIi4vcHVic3ViXCI7XG5pbXBvcnQgY29uZmlnIGZyb20gXCIuL2NvbmZpZy5qc29uXCI7XG5cbihhc3luYyBmdW5jdGlvbiAoKSB7XG4gIGlmIChjb25maWcucG9sa2Fkb3QuZW5hYmxlKSB7XG4gICAgYXdhaXQgcG9sa2Fkb3QoKTtcbiAgfVxuICBpZiAoY29uZmlnLnB1YnN1Yi5lbmFibGUpIHtcbiAgICBwdWJzdWIoKTtcbiAgfVxufSkoKTtcbiJdfQ==