"use strict";

require("core-js/modules/es.array.slice.js");

require("core-js/modules/es.function.name.js");

require("core-js/modules/es.array.from.js");

require("core-js/modules/es.string.iterator.js");

require("core-js/modules/es.symbol.js");

require("core-js/modules/es.symbol.description.js");

require("core-js/modules/es.symbol.iterator.js");

require("core-js/modules/es.array.iterator.js");

require("core-js/modules/web.dom-collections.iterator.js");

require("core-js/modules/es.array.is-array.js");

require("core-js/modules/es.object.define-property.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = _default;

require("regenerator-runtime/runtime.js");

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.promise.js");

require("core-js/modules/es.string.trim.js");

require("core-js/modules/es.date.to-string.js");

require("core-js/modules/es.number.to-fixed.js");

require("core-js/modules/es.array.concat.js");

require("core-js/modules/es.array.filter.js");

require("core-js/modules/web.timers.js");

var _fs = _interopRequireDefault(require("fs"));

var _path = _interopRequireDefault(require("path"));

var _inquirer = _interopRequireDefault(require("inquirer"));

var _robonomicsSubstrate = require("./robonomics-substrate");

var _config = _interopRequireDefault(require("./config.json"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function checkConfig() {
  return _checkConfig.apply(this, arguments);
}

function _checkConfig() {
  _checkConfig = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
    var answers;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (_config["default"].polkadot.account) {
              _context.next = 8;
              break;
            }

            _context.next = 3;
            return _inquirer["default"].prompt([{
              type: "password",
              name: "suri",
              message: "What is your suri account.",
              mask: "*",
              suffix: " (example: //Alice)",
              validate: function validate(input) {
                if (input.trim()) {
                  return true;
                }

                return "You need";
              }
            }, {
              type: "confirm",
              name: "isSave",
              message: "Save suri to config file.",
              "default": false
            }]);

          case 3:
            answers = _context.sent;

            if (answers.suri) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return");

          case 6:
            _config["default"].polkadot.account = answers.suri;

            if (answers.isSave) {
              _fs["default"].writeFileSync(_path["default"].resolve(__dirname, "config.json"), JSON.stringify(_config["default"], null, 2));

              console.log(new Date().toLocaleString(), "[Robonomics]", "Save config file");
            }

          case 8:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _checkConfig.apply(this, arguments);
}

function _default() {
  return _ref.apply(this, arguments);
}

function _ref() {
  _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
    var robonomics;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return checkConfig();

          case 2:
            robonomics = new _robonomicsSubstrate.Robonomics(_config["default"].polkadot.chain);
            robonomics.setAccountManager(new _robonomicsSubstrate.AccountManager());
            robonomics.onReady(function () {
              console.log(new Date().toLocaleString(), "[Robonomics]", "Ready");
              robonomics.accountManager.setAccounts([_config["default"].polkadot.account]);
              robonomics.accountManager.onReady(function () {
                console.log(new Date().toLocaleString(), "[Robonomics]", "Account ".concat(robonomics.accountManager.account.address));

                var worker = function worker() {
                  var logFromDevice = "Random: ".concat(Math.random().toFixed(4));
                  var tx = robonomics.datalog.write(logFromDevice);
                  robonomics.accountManager.signAndSend(tx).then(function (r) {
                    console.log(new Date().toLocaleString(), "[Robonomics]", "https://robonomics.subscan.io/extrinsic/".concat(r.blockNumber, "-").concat(r.txIndex));
                  });
                };

                var interval = false;
                robonomics.launch.on({}, function (events) {
                  events = events.filter(function (item) {
                    return item.robot === robonomics.accountManager.account.address;
                  });

                  var _iterator = _createForOfIteratorHelper(events),
                      _step;

                  try {
                    for (_iterator.s(); !(_step = _iterator.n()).done;) {
                      var event = _step.value;
                      console.log(new Date().toLocaleString(), "[Robonomics]", "New event launch from ".concat(event.account, " | parameter ").concat(event.parameter));

                      if (event.parameter) {
                        console.log(new Date().toLocaleString(), "[Robonomics]", "Run device");
                        clearInterval(interval);
                        worker();
                        interval = setInterval(worker, _config["default"].polkadot.timeout);
                      } else {
                        console.log(new Date().toLocaleString(), "[Robonomics]", "Stop device");
                        clearInterval(interval);
                      }
                    }
                  } catch (err) {
                    _iterator.e(err);
                  } finally {
                    _iterator.f();
                  }
                });
              });
            });

          case 5:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _ref.apply(this, arguments);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9wb2xrYWRvdC5qcyJdLCJuYW1lcyI6WyJjaGVja0NvbmZpZyIsImNvbmZpZyIsInBvbGthZG90IiwiYWNjb3VudCIsImlucXVpcmVyIiwicHJvbXB0IiwidHlwZSIsIm5hbWUiLCJtZXNzYWdlIiwibWFzayIsInN1ZmZpeCIsInZhbGlkYXRlIiwiaW5wdXQiLCJ0cmltIiwiYW5zd2VycyIsInN1cmkiLCJpc1NhdmUiLCJmcyIsIndyaXRlRmlsZVN5bmMiLCJwYXRoIiwicmVzb2x2ZSIsIl9fZGlybmFtZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zb2xlIiwibG9nIiwiRGF0ZSIsInRvTG9jYWxlU3RyaW5nIiwicm9ib25vbWljcyIsIlJvYm9ub21pY3MiLCJjaGFpbiIsInNldEFjY291bnRNYW5hZ2VyIiwiQWNjb3VudE1hbmFnZXIiLCJvblJlYWR5IiwiYWNjb3VudE1hbmFnZXIiLCJzZXRBY2NvdW50cyIsImFkZHJlc3MiLCJ3b3JrZXIiLCJsb2dGcm9tRGV2aWNlIiwiTWF0aCIsInJhbmRvbSIsInRvRml4ZWQiLCJ0eCIsImRhdGFsb2ciLCJ3cml0ZSIsInNpZ25BbmRTZW5kIiwidGhlbiIsInIiLCJibG9ja051bWJlciIsInR4SW5kZXgiLCJpbnRlcnZhbCIsImxhdW5jaCIsIm9uIiwiZXZlbnRzIiwiZmlsdGVyIiwiaXRlbSIsInJvYm90IiwiZXZlbnQiLCJwYXJhbWV0ZXIiLCJjbGVhckludGVydmFsIiwic2V0SW50ZXJ2YWwiLCJ0aW1lb3V0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOzs7Ozs7Ozs7Ozs7OztTQUVlQSxXOzs7Ozt5RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDT0MsbUJBQU9DLFFBQVAsQ0FBZ0JDLE9BRHZCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbUJBRTBCQyxxQkFBU0MsTUFBVCxDQUFnQixDQUNwQztBQUNFQyxjQUFBQSxJQUFJLEVBQUUsVUFEUjtBQUVFQyxjQUFBQSxJQUFJLEVBQUUsTUFGUjtBQUdFQyxjQUFBQSxPQUFPLEVBQUUsNEJBSFg7QUFJRUMsY0FBQUEsSUFBSSxFQUFFLEdBSlI7QUFLRUMsY0FBQUEsTUFBTSxFQUFFLHFCQUxWO0FBTUVDLGNBQUFBLFFBQVEsRUFBRSxrQkFBVUMsS0FBVixFQUFpQjtBQUN6QixvQkFBSUEsS0FBSyxDQUFDQyxJQUFOLEVBQUosRUFBa0I7QUFDaEIseUJBQU8sSUFBUDtBQUNEOztBQUNELHVCQUFPLFVBQVA7QUFDRDtBQVhILGFBRG9DLEVBY3BDO0FBQ0VQLGNBQUFBLElBQUksRUFBRSxTQURSO0FBRUVDLGNBQUFBLElBQUksRUFBRSxRQUZSO0FBR0VDLGNBQUFBLE9BQU8sRUFBRSwyQkFIWDtBQUlFLHlCQUFTO0FBSlgsYUFkb0MsQ0FBaEIsQ0FGMUI7O0FBQUE7QUFFVU0sWUFBQUEsT0FGVjs7QUFBQSxnQkF1QlNBLE9BQU8sQ0FBQ0MsSUF2QmpCO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBMEJJZCwrQkFBT0MsUUFBUCxDQUFnQkMsT0FBaEIsR0FBMEJXLE9BQU8sQ0FBQ0MsSUFBbEM7O0FBQ0EsZ0JBQUlELE9BQU8sQ0FBQ0UsTUFBWixFQUFvQjtBQUNsQkMsNkJBQUdDLGFBQUgsQ0FDRUMsaUJBQUtDLE9BQUwsQ0FBYUMsU0FBYixFQUF3QixhQUF4QixDQURGLEVBRUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFldEIsa0JBQWYsRUFBdUIsSUFBdkIsRUFBNkIsQ0FBN0IsQ0FGRjs7QUFJQXVCLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLElBQUlDLElBQUosR0FBV0MsY0FBWCxFQURGLEVBRUUsY0FGRixFQUdFLGtCQUhGO0FBS0Q7O0FBckNMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEc7Ozs7Ozs7OztpRUF5Q2U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFDUDNCLFdBQVcsRUFESjs7QUFBQTtBQUVQNEIsWUFBQUEsVUFGTyxHQUVNLElBQUlDLCtCQUFKLENBQWU1QixtQkFBT0MsUUFBUCxDQUFnQjRCLEtBQS9CLENBRk47QUFHYkYsWUFBQUEsVUFBVSxDQUFDRyxpQkFBWCxDQUE2QixJQUFJQyxtQ0FBSixFQUE3QjtBQUNBSixZQUFBQSxVQUFVLENBQUNLLE9BQVgsQ0FBbUIsWUFBTTtBQUN2QlQsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBSUMsSUFBSixHQUFXQyxjQUFYLEVBQVosRUFBeUMsY0FBekMsRUFBeUQsT0FBekQ7QUFDQUMsY0FBQUEsVUFBVSxDQUFDTSxjQUFYLENBQTBCQyxXQUExQixDQUFzQyxDQUFDbEMsbUJBQU9DLFFBQVAsQ0FBZ0JDLE9BQWpCLENBQXRDO0FBQ0F5QixjQUFBQSxVQUFVLENBQUNNLGNBQVgsQ0FBMEJELE9BQTFCLENBQWtDLFlBQU07QUFDdENULGdCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FDRSxJQUFJQyxJQUFKLEdBQVdDLGNBQVgsRUFERixFQUVFLGNBRkYsb0JBR2FDLFVBQVUsQ0FBQ00sY0FBWCxDQUEwQi9CLE9BQTFCLENBQWtDaUMsT0FIL0M7O0FBTUEsb0JBQU1DLE1BQU0sR0FBRyxTQUFUQSxNQUFTLEdBQU07QUFDbkIsc0JBQU1DLGFBQWEscUJBQWNDLElBQUksQ0FBQ0MsTUFBTCxHQUFjQyxPQUFkLENBQXNCLENBQXRCLENBQWQsQ0FBbkI7QUFDQSxzQkFBTUMsRUFBRSxHQUFHZCxVQUFVLENBQUNlLE9BQVgsQ0FBbUJDLEtBQW5CLENBQXlCTixhQUF6QixDQUFYO0FBQ0FWLGtCQUFBQSxVQUFVLENBQUNNLGNBQVgsQ0FBMEJXLFdBQTFCLENBQXNDSCxFQUF0QyxFQUEwQ0ksSUFBMUMsQ0FBK0MsVUFBQ0MsQ0FBRCxFQUFPO0FBQ3BEdkIsb0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLElBQUlDLElBQUosR0FBV0MsY0FBWCxFQURGLEVBRUUsY0FGRixvREFHNkNvQixDQUFDLENBQUNDLFdBSC9DLGNBRzhERCxDQUFDLENBQUNFLE9BSGhFO0FBS0QsbUJBTkQ7QUFPRCxpQkFWRDs7QUFZQSxvQkFBSUMsUUFBUSxHQUFHLEtBQWY7QUFDQXRCLGdCQUFBQSxVQUFVLENBQUN1QixNQUFYLENBQWtCQyxFQUFsQixDQUFxQixFQUFyQixFQUF5QixVQUFDQyxNQUFELEVBQVk7QUFDbkNBLGtCQUFBQSxNQUFNLEdBQUdBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLFVBQUNDLElBQUQsRUFBVTtBQUMvQiwyQkFBT0EsSUFBSSxDQUFDQyxLQUFMLEtBQWU1QixVQUFVLENBQUNNLGNBQVgsQ0FBMEIvQixPQUExQixDQUFrQ2lDLE9BQXhEO0FBQ0QsbUJBRlEsQ0FBVDs7QUFEbUMsNkRBSWZpQixNQUplO0FBQUE7O0FBQUE7QUFJbkMsd0VBQTRCO0FBQUEsMEJBQWpCSSxLQUFpQjtBQUMxQmpDLHNCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FDRSxJQUFJQyxJQUFKLEdBQVdDLGNBQVgsRUFERixFQUVFLGNBRkYsa0NBRzJCOEIsS0FBSyxDQUFDdEQsT0FIakMsMEJBR3dEc0QsS0FBSyxDQUFDQyxTQUg5RDs7QUFLQSwwQkFBSUQsS0FBSyxDQUFDQyxTQUFWLEVBQXFCO0FBQ25CbEMsd0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLElBQUlDLElBQUosR0FBV0MsY0FBWCxFQURGLEVBRUUsY0FGRixFQUdFLFlBSEY7QUFLQWdDLHdCQUFBQSxhQUFhLENBQUNULFFBQUQsQ0FBYjtBQUNBYix3QkFBQUEsTUFBTTtBQUNOYSx3QkFBQUEsUUFBUSxHQUFHVSxXQUFXLENBQUN2QixNQUFELEVBQVNwQyxtQkFBT0MsUUFBUCxDQUFnQjJELE9BQXpCLENBQXRCO0FBQ0QsdUJBVEQsTUFTTztBQUNMckMsd0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLElBQUlDLElBQUosR0FBV0MsY0FBWCxFQURGLEVBRUUsY0FGRixFQUdFLGFBSEY7QUFLQWdDLHdCQUFBQSxhQUFhLENBQUNULFFBQUQsQ0FBYjtBQUNEO0FBQ0Y7QUEzQmtDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE0QnBDLGlCQTVCRDtBQTZCRCxlQWpERDtBQWtERCxhQXJERDs7QUFKYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGZzIGZyb20gXCJmc1wiO1xuaW1wb3J0IHBhdGggZnJvbSBcInBhdGhcIjtcbmltcG9ydCBpbnF1aXJlciBmcm9tIFwiaW5xdWlyZXJcIjtcbmltcG9ydCB7IFJvYm9ub21pY3MsIEFjY291bnRNYW5hZ2VyIH0gZnJvbSBcIi4vcm9ib25vbWljcy1zdWJzdHJhdGVcIjtcbmltcG9ydCBjb25maWcgZnJvbSBcIi4vY29uZmlnLmpzb25cIjtcblxuYXN5bmMgZnVuY3Rpb24gY2hlY2tDb25maWcoKSB7XG4gIGlmICghY29uZmlnLnBvbGthZG90LmFjY291bnQpIHtcbiAgICBjb25zdCBhbnN3ZXJzID0gYXdhaXQgaW5xdWlyZXIucHJvbXB0KFtcbiAgICAgIHtcbiAgICAgICAgdHlwZTogXCJwYXNzd29yZFwiLFxuICAgICAgICBuYW1lOiBcInN1cmlcIixcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0IGlzIHlvdXIgc3VyaSBhY2NvdW50LlwiLFxuICAgICAgICBtYXNrOiBcIipcIixcbiAgICAgICAgc3VmZml4OiBcIiAoZXhhbXBsZTogLy9BbGljZSlcIixcbiAgICAgICAgdmFsaWRhdGU6IGZ1bmN0aW9uIChpbnB1dCkge1xuICAgICAgICAgIGlmIChpbnB1dC50cmltKCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gXCJZb3UgbmVlZFwiO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdHlwZTogXCJjb25maXJtXCIsXG4gICAgICAgIG5hbWU6IFwiaXNTYXZlXCIsXG4gICAgICAgIG1lc3NhZ2U6IFwiU2F2ZSBzdXJpIHRvIGNvbmZpZyBmaWxlLlwiLFxuICAgICAgICBkZWZhdWx0OiBmYWxzZSxcbiAgICAgIH0sXG4gICAgXSk7XG4gICAgaWYgKCFhbnN3ZXJzLnN1cmkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uZmlnLnBvbGthZG90LmFjY291bnQgPSBhbnN3ZXJzLnN1cmk7XG4gICAgaWYgKGFuc3dlcnMuaXNTYXZlKSB7XG4gICAgICBmcy53cml0ZUZpbGVTeW5jKFxuICAgICAgICBwYXRoLnJlc29sdmUoX19kaXJuYW1lLCBcImNvbmZpZy5qc29uXCIpLFxuICAgICAgICBKU09OLnN0cmluZ2lmeShjb25maWcsIG51bGwsIDIpXG4gICAgICApO1xuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoKSxcbiAgICAgICAgXCJbUm9ib25vbWljc11cIixcbiAgICAgICAgXCJTYXZlIGNvbmZpZyBmaWxlXCJcbiAgICAgICk7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgYXdhaXQgY2hlY2tDb25maWcoKTtcbiAgY29uc3Qgcm9ib25vbWljcyA9IG5ldyBSb2Jvbm9taWNzKGNvbmZpZy5wb2xrYWRvdC5jaGFpbik7XG4gIHJvYm9ub21pY3Muc2V0QWNjb3VudE1hbmFnZXIobmV3IEFjY291bnRNYW5hZ2VyKCkpO1xuICByb2Jvbm9taWNzLm9uUmVhZHkoKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoKSwgXCJbUm9ib25vbWljc11cIiwgXCJSZWFkeVwiKTtcbiAgICByb2Jvbm9taWNzLmFjY291bnRNYW5hZ2VyLnNldEFjY291bnRzKFtjb25maWcucG9sa2Fkb3QuYWNjb3VudF0pO1xuICAgIHJvYm9ub21pY3MuYWNjb3VudE1hbmFnZXIub25SZWFkeSgoKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygpLFxuICAgICAgICBcIltSb2Jvbm9taWNzXVwiLFxuICAgICAgICBgQWNjb3VudCAke3JvYm9ub21pY3MuYWNjb3VudE1hbmFnZXIuYWNjb3VudC5hZGRyZXNzfWBcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IHdvcmtlciA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgbG9nRnJvbURldmljZSA9IGBSYW5kb206ICR7TWF0aC5yYW5kb20oKS50b0ZpeGVkKDQpfWA7XG4gICAgICAgIGNvbnN0IHR4ID0gcm9ib25vbWljcy5kYXRhbG9nLndyaXRlKGxvZ0Zyb21EZXZpY2UpO1xuICAgICAgICByb2Jvbm9taWNzLmFjY291bnRNYW5hZ2VyLnNpZ25BbmRTZW5kKHR4KS50aGVuKChyKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCksXG4gICAgICAgICAgICBcIltSb2Jvbm9taWNzXVwiLFxuICAgICAgICAgICAgYGh0dHBzOi8vcm9ib25vbWljcy5zdWJzY2FuLmlvL2V4dHJpbnNpYy8ke3IuYmxvY2tOdW1iZXJ9LSR7ci50eEluZGV4fWBcbiAgICAgICAgICApO1xuICAgICAgICB9KTtcbiAgICAgIH07XG5cbiAgICAgIGxldCBpbnRlcnZhbCA9IGZhbHNlO1xuICAgICAgcm9ib25vbWljcy5sYXVuY2gub24oe30sIChldmVudHMpID0+IHtcbiAgICAgICAgZXZlbnRzID0gZXZlbnRzLmZpbHRlcigoaXRlbSkgPT4ge1xuICAgICAgICAgIHJldHVybiBpdGVtLnJvYm90ID09PSByb2Jvbm9taWNzLmFjY291bnRNYW5hZ2VyLmFjY291bnQuYWRkcmVzcztcbiAgICAgICAgfSk7XG4gICAgICAgIGZvciAoY29uc3QgZXZlbnQgb2YgZXZlbnRzKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCksXG4gICAgICAgICAgICBcIltSb2Jvbm9taWNzXVwiLFxuICAgICAgICAgICAgYE5ldyBldmVudCBsYXVuY2ggZnJvbSAke2V2ZW50LmFjY291bnR9IHwgcGFyYW1ldGVyICR7ZXZlbnQucGFyYW1ldGVyfWBcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChldmVudC5wYXJhbWV0ZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCksXG4gICAgICAgICAgICAgIFwiW1JvYm9ub21pY3NdXCIsXG4gICAgICAgICAgICAgIFwiUnVuIGRldmljZVwiXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gICAgICAgICAgICB3b3JrZXIoKTtcbiAgICAgICAgICAgIGludGVydmFsID0gc2V0SW50ZXJ2YWwod29ya2VyLCBjb25maWcucG9sa2Fkb3QudGltZW91dCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCksXG4gICAgICAgICAgICAgIFwiW1JvYm9ub21pY3NdXCIsXG4gICAgICAgICAgICAgIFwiU3RvcCBkZXZpY2VcIlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH0pO1xufVxuIl19