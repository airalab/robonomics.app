"use strict";

require("core-js/modules/es.object.define-property.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = _default;

require("core-js/modules/es.object.to-string.js");

require("core-js/modules/es.promise.js");

require("core-js/modules/es.date.to-string.js");

require("core-js/modules/es.regexp.to-string.js");

require("core-js/modules/es.date.now.js");

require("core-js/modules/web.timers.js");

require("regenerator-runtime/runtime.js");

var _config = _interopRequireDefault(require("./config.json"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var Libp2p = require("libp2p");

var Mplex = require("libp2p-mplex");

var _require = require("libp2p-noise"),
    NOISE = _require.NOISE;

var Gossipsub = require("libp2p-gossipsub");

var Websockets = require("libp2p-websockets");

var Bootstrap = require("libp2p-bootstrap");

var createNode = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(listen) {
    var node;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return Libp2p.create({
              addresses: {
                listen: listen
              },
              modules: {
                transport: [Websockets],
                streamMuxer: [Mplex],
                connEncryption: [NOISE],
                pubsub: Gossipsub,
                peerDiscovery: [Bootstrap]
              },
              config: {
                peerDiscovery: _defineProperty({}, Bootstrap.tag, {
                  enabled: true,
                  list: ["/dns4/1.pubsub.aira.life/tcp/443/wss/ipfs/QmdfQmbmXt6sqjZyowxPUsmvBsgSGQjm4VXrV7WGy62dv8", "/dns4/2.pubsub.aira.life/tcp/443/wss/ipfs/QmPTFt7GJ2MfDuVYwJJTULr6EnsQtGVp8ahYn9NSyoxmd9", "/dns4/3.pubsub.aira.life/tcp/443/wss/ipfs/QmWZSKTEQQ985mnNzMqhGCrwQ1aTA6sxVsorsycQz9cQrw"]
                })
              }
            });

          case 2:
            node = _context.sent;
            _context.next = 5;
            return node.start();

          case 5:
            return _context.abrupt("return", node);

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function createNode(_x) {
    return _ref.apply(this, arguments);
  };
}();

function _default() {
  return _ref2.apply(this, arguments);
}

function _ref2() {
  _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
    var node, worker;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return createNode(["/ip4/0.0.0.0/tcp/10333/ws"]);

          case 2:
            node = _context2.sent;
            console.log(new Date().toLocaleString(), "[Pubsub]", "Ready");
            console.log(new Date().toLocaleString(), "[Pubsub]", "PeerId ".concat(node.peerId.toB58String()));
            node.pubsub.on(_config["default"].pubsub.topic, function (msg) {
              try {
                var data = JSON.parse(msg.data.toString());

                if (data.time && data.id === _config["default"].pubsub.id_name) {
                  console.log(new Date().toLocaleString(), "[Pubsub]", msg.data.toString());
                }
              } catch (e) {
                console.log(new Date().toLocaleString(), "[Pubsub]", e.messge);
              }
            });
            _context2.next = 8;
            return node.pubsub.subscribe(_config["default"].pubsub.topic);

          case 8:
            worker = function worker() {
              node.pubsub.publish(_config["default"].pubsub.topic, Buffer.from(JSON.stringify({
                time: Date.now(),
                id: _config["default"].pubsub.id_name,
                type: "iot"
              })));
            };

            worker();
            setInterval(worker, _config["default"].pubsub.timeout);

          case 11:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _ref2.apply(this, arguments);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9wdWJzdWIuanMiXSwibmFtZXMiOlsiTGlicDJwIiwicmVxdWlyZSIsIk1wbGV4IiwiTk9JU0UiLCJHb3NzaXBzdWIiLCJXZWJzb2NrZXRzIiwiQm9vdHN0cmFwIiwiY3JlYXRlTm9kZSIsImxpc3RlbiIsImNyZWF0ZSIsImFkZHJlc3NlcyIsIm1vZHVsZXMiLCJ0cmFuc3BvcnQiLCJzdHJlYW1NdXhlciIsImNvbm5FbmNyeXB0aW9uIiwicHVic3ViIiwicGVlckRpc2NvdmVyeSIsImNvbmZpZyIsInRhZyIsImVuYWJsZWQiLCJsaXN0Iiwibm9kZSIsInN0YXJ0IiwiY29uc29sZSIsImxvZyIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsInBlZXJJZCIsInRvQjU4U3RyaW5nIiwib24iLCJ0b3BpYyIsIm1zZyIsImRhdGEiLCJKU09OIiwicGFyc2UiLCJ0b1N0cmluZyIsInRpbWUiLCJpZCIsImlkX25hbWUiLCJlIiwibWVzc2dlIiwic3Vic2NyaWJlIiwid29ya2VyIiwicHVibGlzaCIsIkJ1ZmZlciIsImZyb20iLCJzdHJpbmdpZnkiLCJub3ciLCJ0eXBlIiwic2V0SW50ZXJ2YWwiLCJ0aW1lb3V0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU1BOzs7Ozs7Ozs7O0FBTkEsSUFBTUEsTUFBTSxHQUFHQyxPQUFPLENBQUMsUUFBRCxDQUF0Qjs7QUFDQSxJQUFNQyxLQUFLLEdBQUdELE9BQU8sQ0FBQyxjQUFELENBQXJCOztBQUNBLGVBQWtCQSxPQUFPLENBQUMsY0FBRCxDQUF6QjtBQUFBLElBQVFFLEtBQVIsWUFBUUEsS0FBUjs7QUFDQSxJQUFNQyxTQUFTLEdBQUdILE9BQU8sQ0FBQyxrQkFBRCxDQUF6Qjs7QUFDQSxJQUFNSSxVQUFVLEdBQUdKLE9BQU8sQ0FBQyxtQkFBRCxDQUExQjs7QUFDQSxJQUFNSyxTQUFTLEdBQUdMLE9BQU8sQ0FBQyxrQkFBRCxDQUF6Qjs7QUFHQSxJQUFNTSxVQUFVO0FBQUEscUVBQUcsaUJBQU9DLE1BQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFDRVIsTUFBTSxDQUFDUyxNQUFQLENBQWM7QUFDL0JDLGNBQUFBLFNBQVMsRUFBRTtBQUNURixnQkFBQUEsTUFBTSxFQUFFQTtBQURDLGVBRG9CO0FBSS9CRyxjQUFBQSxPQUFPLEVBQUU7QUFDUEMsZ0JBQUFBLFNBQVMsRUFBRSxDQUFDUCxVQUFELENBREo7QUFFUFEsZ0JBQUFBLFdBQVcsRUFBRSxDQUFDWCxLQUFELENBRk47QUFHUFksZ0JBQUFBLGNBQWMsRUFBRSxDQUFDWCxLQUFELENBSFQ7QUFJUFksZ0JBQUFBLE1BQU0sRUFBRVgsU0FKRDtBQUtQWSxnQkFBQUEsYUFBYSxFQUFFLENBQUNWLFNBQUQ7QUFMUixlQUpzQjtBQVcvQlcsY0FBQUEsTUFBTSxFQUFFO0FBQ05ELGdCQUFBQSxhQUFhLHNCQUNWVixTQUFTLENBQUNZLEdBREEsRUFDTTtBQUNmQyxrQkFBQUEsT0FBTyxFQUFFLElBRE07QUFFZkMsa0JBQUFBLElBQUksRUFBRSxDQUNKLDBGQURJLEVBRUosMEZBRkksRUFHSiwwRkFISTtBQUZTLGlCQUROO0FBRFA7QUFYdUIsYUFBZCxDQURGOztBQUFBO0FBQ1hDLFlBQUFBLElBRFc7QUFBQTtBQUFBLG1CQTBCWEEsSUFBSSxDQUFDQyxLQUFMLEVBMUJXOztBQUFBO0FBQUEsNkNBMkJWRCxJQTNCVTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUFIOztBQUFBLGtCQUFWZCxVQUFVO0FBQUE7QUFBQTtBQUFBLEdBQWhCOzs7Ozs7O2tFQThCZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUNNQSxVQUFVLENBQUMsQ0FBQywyQkFBRCxDQUFELENBRGhCOztBQUFBO0FBQ1BjLFlBQUFBLElBRE87QUFHYkUsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBSUMsSUFBSixHQUFXQyxjQUFYLEVBQVosRUFBeUMsVUFBekMsRUFBcUQsT0FBckQ7QUFFQUgsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQ0UsSUFBSUMsSUFBSixHQUFXQyxjQUFYLEVBREYsRUFFRSxVQUZGLG1CQUdZTCxJQUFJLENBQUNNLE1BQUwsQ0FBWUMsV0FBWixFQUhaO0FBTUFQLFlBQUFBLElBQUksQ0FBQ04sTUFBTCxDQUFZYyxFQUFaLENBQWVaLG1CQUFPRixNQUFQLENBQWNlLEtBQTdCLEVBQW9DLFVBQUNDLEdBQUQsRUFBUztBQUMzQyxrQkFBSTtBQUNGLG9CQUFNQyxJQUFJLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxHQUFHLENBQUNDLElBQUosQ0FBU0csUUFBVCxFQUFYLENBQWI7O0FBQ0Esb0JBQUlILElBQUksQ0FBQ0ksSUFBTCxJQUFhSixJQUFJLENBQUNLLEVBQUwsS0FBWXBCLG1CQUFPRixNQUFQLENBQWN1QixPQUEzQyxFQUFvRDtBQUNsRGYsa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUNFLElBQUlDLElBQUosR0FBV0MsY0FBWCxFQURGLEVBRUUsVUFGRixFQUdFSyxHQUFHLENBQUNDLElBQUosQ0FBU0csUUFBVCxFQUhGO0FBS0Q7QUFDRixlQVRELENBU0UsT0FBT0ksQ0FBUCxFQUFVO0FBQ1ZoQixnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBSUMsSUFBSixHQUFXQyxjQUFYLEVBQVosRUFBeUMsVUFBekMsRUFBcURhLENBQUMsQ0FBQ0MsTUFBdkQ7QUFDRDtBQUNGLGFBYkQ7QUFYYTtBQUFBLG1CQXlCUG5CLElBQUksQ0FBQ04sTUFBTCxDQUFZMEIsU0FBWixDQUFzQnhCLG1CQUFPRixNQUFQLENBQWNlLEtBQXBDLENBekJPOztBQUFBO0FBMkJQWSxZQUFBQSxNQTNCTyxHQTJCRSxTQUFUQSxNQUFTLEdBQU07QUFDbkJyQixjQUFBQSxJQUFJLENBQUNOLE1BQUwsQ0FBWTRCLE9BQVosQ0FDRTFCLG1CQUFPRixNQUFQLENBQWNlLEtBRGhCLEVBRUVjLE1BQU0sQ0FBQ0MsSUFBUCxDQUNFWixJQUFJLENBQUNhLFNBQUwsQ0FBZTtBQUNiVixnQkFBQUEsSUFBSSxFQUFFWCxJQUFJLENBQUNzQixHQUFMLEVBRE87QUFFYlYsZ0JBQUFBLEVBQUUsRUFBRXBCLG1CQUFPRixNQUFQLENBQWN1QixPQUZMO0FBR2JVLGdCQUFBQSxJQUFJLEVBQUU7QUFITyxlQUFmLENBREYsQ0FGRjtBQVVELGFBdENZOztBQXVDYk4sWUFBQUEsTUFBTTtBQUNOTyxZQUFBQSxXQUFXLENBQUNQLE1BQUQsRUFBU3pCLG1CQUFPRixNQUFQLENBQWNtQyxPQUF2QixDQUFYOztBQXhDYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTGlicDJwID0gcmVxdWlyZShcImxpYnAycFwiKTtcbmNvbnN0IE1wbGV4ID0gcmVxdWlyZShcImxpYnAycC1tcGxleFwiKTtcbmNvbnN0IHsgTk9JU0UgfSA9IHJlcXVpcmUoXCJsaWJwMnAtbm9pc2VcIik7XG5jb25zdCBHb3NzaXBzdWIgPSByZXF1aXJlKFwibGlicDJwLWdvc3NpcHN1YlwiKTtcbmNvbnN0IFdlYnNvY2tldHMgPSByZXF1aXJlKFwibGlicDJwLXdlYnNvY2tldHNcIik7XG5jb25zdCBCb290c3RyYXAgPSByZXF1aXJlKFwibGlicDJwLWJvb3RzdHJhcFwiKTtcbmltcG9ydCBjb25maWcgZnJvbSBcIi4vY29uZmlnLmpzb25cIjtcblxuY29uc3QgY3JlYXRlTm9kZSA9IGFzeW5jIChsaXN0ZW4pID0+IHtcbiAgY29uc3Qgbm9kZSA9IGF3YWl0IExpYnAycC5jcmVhdGUoe1xuICAgIGFkZHJlc3Nlczoge1xuICAgICAgbGlzdGVuOiBsaXN0ZW4sXG4gICAgfSxcbiAgICBtb2R1bGVzOiB7XG4gICAgICB0cmFuc3BvcnQ6IFtXZWJzb2NrZXRzXSxcbiAgICAgIHN0cmVhbU11eGVyOiBbTXBsZXhdLFxuICAgICAgY29ubkVuY3J5cHRpb246IFtOT0lTRV0sXG4gICAgICBwdWJzdWI6IEdvc3NpcHN1YixcbiAgICAgIHBlZXJEaXNjb3Zlcnk6IFtCb290c3RyYXBdLFxuICAgIH0sXG4gICAgY29uZmlnOiB7XG4gICAgICBwZWVyRGlzY292ZXJ5OiB7XG4gICAgICAgIFtCb290c3RyYXAudGFnXToge1xuICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgbGlzdDogW1xuICAgICAgICAgICAgXCIvZG5zNC8xLnB1YnN1Yi5haXJhLmxpZmUvdGNwLzQ0My93c3MvaXBmcy9RbWRmUW1ibVh0NnNxalp5b3d4UFVzbXZCc2dTR1FqbTRWWHJWN1dHeTYyZHY4XCIsXG4gICAgICAgICAgICBcIi9kbnM0LzIucHVic3ViLmFpcmEubGlmZS90Y3AvNDQzL3dzcy9pcGZzL1FtUFRGdDdHSjJNZkR1Vll3SkpUVUxyNkVuc1F0R1ZwOGFoWW45TlN5b3htZDlcIixcbiAgICAgICAgICAgIFwiL2RuczQvMy5wdWJzdWIuYWlyYS5saWZlL3RjcC80NDMvd3NzL2lwZnMvUW1XWlNLVEVRUTk4NW1uTnpNcWhHQ3J3UTFhVEE2c3hWc29yc3ljUXo5Y1Fyd1wiLFxuICAgICAgICAgIF0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gIH0pO1xuXG4gIGF3YWl0IG5vZGUuc3RhcnQoKTtcbiAgcmV0dXJuIG5vZGU7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiAoKSB7XG4gIGNvbnN0IG5vZGUgPSBhd2FpdCBjcmVhdGVOb2RlKFtcIi9pcDQvMC4wLjAuMC90Y3AvMTAzMzMvd3NcIl0pO1xuXG4gIGNvbnNvbGUubG9nKG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoKSwgXCJbUHVic3ViXVwiLCBcIlJlYWR5XCIpO1xuXG4gIGNvbnNvbGUubG9nKFxuICAgIG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoKSxcbiAgICBcIltQdWJzdWJdXCIsXG4gICAgYFBlZXJJZCAke25vZGUucGVlcklkLnRvQjU4U3RyaW5nKCl9YFxuICApO1xuXG4gIG5vZGUucHVic3ViLm9uKGNvbmZpZy5wdWJzdWIudG9waWMsIChtc2cpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UobXNnLmRhdGEudG9TdHJpbmcoKSk7XG4gICAgICBpZiAoZGF0YS50aW1lICYmIGRhdGEuaWQgPT09IGNvbmZpZy5wdWJzdWIuaWRfbmFtZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCksXG4gICAgICAgICAgXCJbUHVic3ViXVwiLFxuICAgICAgICAgIG1zZy5kYXRhLnRvU3RyaW5nKClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmxvZyhuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCksIFwiW1B1YnN1Yl1cIiwgZS5tZXNzZ2UpO1xuICAgIH1cbiAgfSk7XG4gIGF3YWl0IG5vZGUucHVic3ViLnN1YnNjcmliZShjb25maWcucHVic3ViLnRvcGljKTtcblxuICBjb25zdCB3b3JrZXIgPSAoKSA9PiB7XG4gICAgbm9kZS5wdWJzdWIucHVibGlzaChcbiAgICAgIGNvbmZpZy5wdWJzdWIudG9waWMsXG4gICAgICBCdWZmZXIuZnJvbShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIHRpbWU6IERhdGUubm93KCksXG4gICAgICAgICAgaWQ6IGNvbmZpZy5wdWJzdWIuaWRfbmFtZSxcbiAgICAgICAgICB0eXBlOiBcImlvdFwiLFxuICAgICAgICB9KVxuICAgICAgKVxuICAgICk7XG4gIH07XG4gIHdvcmtlcigpO1xuICBzZXRJbnRlcnZhbCh3b3JrZXIsIGNvbmZpZy5wdWJzdWIudGltZW91dCk7XG59XG4iXX0=